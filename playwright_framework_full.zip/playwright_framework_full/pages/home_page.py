
from pages.base_page import BasePage
from utils.ui_helpers import UIHelpers


class HomePage(BasePage):
    # Example home page methods if needed
    INVENTORY_LIST = ".inventory_list"
    SELECT = "select.product_sort_container"

    def __init__(self, page):
        super().__init__(page)
        self.ui = UIHelpers(page)

    def select_dropdown(self, value):
        self.ui.select_dropdown(self.SELECT, label = value)

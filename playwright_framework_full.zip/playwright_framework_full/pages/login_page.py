
from pages.base_page import BasePage
from utils.ui_helpers import UIHelpers
from utils import config

class LoginPage(BasePage):
    # Sauce Demo selectors
    USERNAME = "#user-name"
    PASSWORD = "#password"
    LOGIN_BTN = "#login-button"
    ERROR = "[data-test='error']"
    PRODUCTS_TITLE = ".title"

    def __init__(self, page):
        super().__init__(page)
        self.ui = UIHelpers(page)

    def open(self):
        self.open_url(config.BASE_URL)

    def login(self, username: str, password: str):
        self.ui.enter_text_action(self.USERNAME, username)
        self.ui.enter_text_action(self.PASSWORD, password)
        self.ui.click(self.LOGIN_BTN)

    def login_successful(self) -> bool:
        return self.ui.is_visible(self.PRODUCTS_TITLE)

    def error_message(self) -> str:
        return self.ui.get_text(self.ERROR)

import time

from pages.home_page import HomePage
from pages.login_page import LoginPage
from utils import config
from utils.ui_helpers import UIHelpers


def test_valid_login(page):
    login = LoginPage(page)
    ui = UIHelpers(page)
    login.login(config.VALID_USERNAME, config.VALID_PASSWORD)
    time.sleep(3)
    assert login.login_successful(), "User should land on Products page after valid login"

def test_select_dropdown(page):
    login = LoginPage(page)
    ui = UIHelpers(page)
    hp = HomePage(page)
    login.login(config.VALID_USERNAME, config.VALID_PASSWORD)
    time.sleep(3)
    assert login.login_successful(), "User should land on Products page after valid login"
    hp.select_dropdown("Price (low to high)")
    time.sleep(3)
    elements = page.locator("div.inventory_item_name ").element_handles()
    for el in elements:
        print(el.text_content())
        time.sleep(1)


import pytest
from pages.login_page import LoginPage
from utils.data_reader import read_json
from utils import config

test_data = read_json("testdata/login_data.json")

@pytest.mark.parametrize("data", test_data)
def test_login_data_json(page, data):
    login = LoginPage(page)
    login.login(data["username"], data["password"])

    expected = data["expected"]
    if expected == "success":
        assert login.login_successful(), "Expected successful login"
    else:
        assert "Epic sadface" in login.error_message()

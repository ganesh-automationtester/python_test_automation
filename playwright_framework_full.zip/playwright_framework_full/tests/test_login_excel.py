import time

import pytest
from pages.login_page import LoginPage
from utils.data_reader import read_excel

records = read_excel("C:/Users/ganeshvinodrao_dubbe/PycharmProjects/playwright_framework_full/testdata/login_data.xlsx", sheet_name="Sheet1")

@pytest.mark.parametrize("data", records)
def test_login_data_excel(page, data):
    login = LoginPage(page)
    login.login(data["username"], data["password"])
    time.sleep(3)
    if data["expected"] == "success":
        assert login.login_successful()
    else:
        # Sauce Demo shows 'Epic sadface: ...'
        # We just assert that error element is visible/text exists
        assert login.error_message()

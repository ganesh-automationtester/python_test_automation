
import os
import glob
import pytest
import allure
from playwright.sync_api import sync_playwright
from utils import config
from utils.ui_helpers import UIHelpers

@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as p:
        browser = getattr(p, config.BROWSER).launch(headless=config.HEADLESS)
        yield browser
        browser.close()

@pytest.fixture
def context(browser, request):
    # Per-test video directory
    video_dir = os.path.join("videos", request.node.name)
    os.makedirs(video_dir, exist_ok=True)
    context = browser.new_context(
        record_video_dir=video_dir,
        viewport={'width': 1366, 'height': 768}
    )
    context.clear_cookies()
    # Attach console errors to Allure
    context.on("page", lambda page: page.on("console", lambda msg: 
        allure.attach(
            f"{msg.type.upper()}: {msg.text}",
            name=f"console_{request.node.name}",
            attachment_type=allure.attachment_type.TEXT
        ) if msg.type == "error" else None
    ))
    yield context
    context.close()

@pytest.fixture
def page(context):
    page = context.new_page()
    ui = UIHelpers(page)
    page.set_viewport_size({"width": 1920, "height": 1080})
    ui.open_url(config.BASE_URL)
    yield page
    page.close()

# Hook: attach screenshot on failure and video always
@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()

    if report.when == "call":
        # Screenshot on failure
        if report.failed:
            page = item.funcargs.get("page", None)
            if page:
                os.makedirs("screenshots", exist_ok=True)
                shot_path = os.path.join("screenshots", f"{item.name}.png")
                try:
                    page.screenshot(path=shot_path, full_page=True)
                    allure.attach.file(
                        shot_path,
                        name=f"Screenshot_{item.name}",
                        attachment_type=allure.attachment_type.PNG
                    )
                except Exception as e:
                    allure.attach(str(e), name="screenshot_error", attachment_type=allure.attachment_type.TEXT)

        # Attach any produced video(s)
        video_dir = os.path.join("videos", item.name)
        video_files = glob.glob(os.path.join(video_dir, "*.webm")) + glob.glob(os.path.join(video_dir, "*.mp4"))
        for vf in video_files:
            try:
                allure.attach.file(
                    vf,
                    name=f"Video_{item.name}",
                    attachment_type=allure.attachment_type.WEBM if vf.endswith(".webm") else allure.attachment_type.MP4
                )
            except Exception as e:
                allure.attach(str(e), name="video_attach_error", attachment_type=allure.attachment_type.TEXT)

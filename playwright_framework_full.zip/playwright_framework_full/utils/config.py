
# --- Runtime configuration ---
# Target app (Sauce Demo public site)
BASE_URL = "https://www.saucedemo.com/"
VALID_USERNAME = "standard_user"
VALID_PASSWORD = "secret_sauce"

# Browser: 'chromium', 'firefox', or 'webkit'
BROWSER = "chromium"
HEADLESS = False

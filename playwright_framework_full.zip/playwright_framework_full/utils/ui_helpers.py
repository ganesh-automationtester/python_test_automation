# ui_helpers.py
import time
from playwright.sync_api import Page, expect

from utils.loggerUtils import Logger

log = Logger().get_logger()

class UIHelpers:
    def __init__(self, page: Page):
        self.page = page

    # -------------------- BASIC ACTIONS --------------------
    def open_url(self, url: str):
        self.page.goto(url)

    def click(self, selector: str):
        if self.is_element_clickable(selector):
            self.page.locator(selector).click()

    def enter_text_action(self, selector: str, text: str, clear_first: bool = True):
        locator = self.page.locator(selector)
        if clear_first:
            locator.fill("")
        locator.type(text)

    def clear(self, selector: str):
        self.page.locator(selector).fill("")

    def get_text(self, selector: str) -> str:
        return self.page.locator(selector).inner_text()

    def get_attribute(self, selector: str, attribute: str) -> str:
        return self.page.locator(selector).get_attribute(attribute)

    def is_visible(self, selector: str) -> bool:
        return self.page.is_visible(selector)

    def get_page_title(self):
        return self.page.title()

    def is_element_clickable(self, selector: str) -> bool:
        """
        Checks if the element is clickable (visible and enabled).
        Equivalent to Selenium's element_to_be_clickable.
        Returns True/False.
        """
        try:
            element = self.page.query_selector(selector)
            if element and element.is_visible() and element.is_enabled():
                return True
            return False
        except:
            return False

    def is_element_checked(self, selector: str) -> bool:
        """
        Checks if a checkbox or radio button is checked.
        Equivalent to Selenium's is_selected().
        Returns True/False.
        """
        try:
            return self.page.is_checked(selector)
        except:
            return False

    def verify_elements_located(self, selector: str, timeout: int = 5000) -> bool:
        """
        Verifies that one or more elements are located in the DOM within the timeout.
        Equivalent to Selenium's presence_of_all_elements_located.
        Returns True if found, False if not.
        """
        try:
            # Wait for at least one element to appear
            self.page.wait_for_selector(selector, state="attached", timeout=timeout)
            elements = self.page.query_selector_all(selector)
            return len(elements) > 0
        except:
            return False

    def get_element_list(self, selector: str) -> list:
        """
        Returns a list of elements or their texts.

        :param selector: CSS/XPath locator
        :return: list of strings or element handles
        """
        try:
            elements = self.page.query_selector_all(selector)
            return elements
        except:
            return []

    # -------------------- WAITS --------------------
    def implicit_wait(self, timeout: int = 5000):
        self.page.set_default_timeout(timeout)

    def wait_for_element_to_be_present(self, selector: str, timeout: int = 5000):
        """
        Waits until element is present in DOM (not necessarily visible).
        Equivalent to Selenium's presence_of_element_located.
        """
        return self.page.wait_for_selector(selector, state="attached", timeout=timeout)

    def wait_for_element_to_be_visible(self, selector: str, timeout: int = 5000):
        """
        Waits until element is visible in DOM.
        Equivalent to Selenium's visibility_of_element_located.
        """
        return self.page.wait_for_selector(selector, state="visible", timeout=timeout)

    def wait_for_element_to_be_hidden(self, selector: str, timeout: int = 5000):
        """
        Waits until element becomes hidden.
        Equivalent to Selenium's invisibility_of_element_located.
        """
        return self.page.wait_for_selector(selector, state="hidden", timeout=timeout)

    def wait_for_element_to_be_detached(self, selector: str, timeout: int = 5000):
        """
        Waits until element is removed from the DOM.
        Equivalent to Selenium's staleness_of.
        """
        return self.page.wait_for_selector(selector, state="detached", timeout=timeout)

    # -------------------- DROPDOWNS --------------------
    def select_by_value(self, selector: str, value: str):
        self.page.select_option(selector, value=value)

    def select_by_label(self, selector: str, label: str):
        self.page.select_option(selector, label=label)

    def select_by_index(self, selector: str, index: int):
        options = self.page.locator(selector + " option")
        self.page.select_option(selector, index=index)

    # -------------------- ALERTS --------------------
    def handle_alert(self, action: str = "accept", prompt_text: str = None):
        def dialog_handler(dialog):
            if action == "accept":
                dialog.accept(prompt_text if prompt_text else None)
            else:
                dialog.dismiss()
        self.page.once("dialog", dialog_handler)

    # -------------------- IFRAMES --------------------
    def switch_to_frame(self, frame_name: str):
        return self.page.frame(name=frame_name)

    def switch_to_frame_by_url(self, url: str):
        return self.page.frame(url=url)

    # -------------------- MULTIPLE TABS --------------------
    def switch_to_new_tab(self, context):
        new_page = context.wait_for_event("page")
        return new_page

    def switch_to_tab(self, context, index: int):
        return context.pages[index]

    # -------------------- MOUSE ACTIONS --------------------
    def hover(self, selector: str):
        self.page.locator(selector).hover()

    def right_click(self, selector: str):
        self.page.locator(selector).click(button="right")

    def double_click(self, selector: str):
        self.page.locator(selector).dblclick()

    def drag_and_drop(self, source: str, target: str):
        self.page.locator(source).drag_to(self.page.locator(target))

    # -------------------- KEYBOARD --------------------
    def press_key(self, selector: str, key: str):
        self.page.locator(selector).press(key)

    def press_hotkey(self, *keys: str):
        self.page.keyboard.press("+".join(keys))

    # -------------------- COOKIES --------------------
    def get_cookies(self, context):
        return context.cookies()

    def add_cookie(self, context, cookie: dict):
        context.add_cookies([cookie])

    def clear_cookies(self, context):
        context.clear_cookies()

    # -------------------- FILE UPLOAD/DOWNLOAD --------------------
    def upload_file(self, selector: str, file_path: str):
        self.page.locator(selector).set_input_files(file_path)

    def download_file(self, download_button_selector: str, save_path: str):
        with self.page.expect_download() as download_info:
            self.page.click(download_button_selector)
        download = download_info.value
        download.save_as(save_path)

    # -------------------- JAVASCRIPT EXECUTION --------------------
    def execute_script(self, script: str, *args):
        return self.page.evaluate(script, *args)

    # -------------------- ELEMENT STATE --------------------
    def is_enabled(self, selector: str) -> bool:
        return self.page.is_enabled(selector)

    def is_checked(self, selector: str) -> bool:
        return self.page.is_checked(selector)

    def is_disabled(self, selector: str) -> bool:
        return self.page.is_disabled(selector)

    # -------------------- SCROLLING --------------------
    def scroll_to_end(self):
        self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")

    def scroll_to_element(self, selector: str):
        self.page.locator(selector).scroll_into_view_if_needed()

    # -------------------- SCREENSHOTS & VIDEOS --------------------
    def take_screenshot(self, path: str):
        self.page.screenshot(path=path)

    def take_full_page_screenshot(self, path: str):
        self.page.screenshot(path=path, full_page=True)

    # -------------------- ASSERTIONS --------------------
    def assert_text_contains(self, selector: str, text: str):
        actual = self.page.locator(selector).inner_text()
        assert text in actual, f"Expected '{text}' in '{actual}'"

    def assert_element_visible(self, selector: str):
        expect(self.page.locator(selector)).to_be_visible()

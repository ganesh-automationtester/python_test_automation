import logging
import os
from datetime import datetime

class Logger:
    def __init__(self, log_dir="logs", log_file=None):
        os.makedirs(log_dir, exist_ok=True)

        if not log_file:
            log_file = "automation.log"
        self.log_path = os.path.join(log_dir, log_file)

        self.logger = logging.getLogger("UIAutomation")
        self.logger.setLevel(logging.INFO)

        # Avoid duplicate handlers if Logger() is called multiple times
        if not self.logger.handlers:
            formatter = logging.Formatter(
                "[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )

            # File Handler
            file_handler = logging.FileHandler(self.log_path, mode="a", encoding="utf-8")
            file_handler.setFormatter(formatter)

            # Console Handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)

            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)

    def get_logger(self):
        return self.logger

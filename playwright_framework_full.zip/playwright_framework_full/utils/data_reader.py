
import csv
import json
import pandas as pd

def read_csv(file_path: str):
    with open(file_path, newline='', encoding='utf-8') as f:
        return [row for row in csv.DictReader(f)]

def read_json(file_path: str):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def read_excel(file_path: str, sheet_name=0):
    df = pd.read_excel(file_path, sheet_name=sheet_name)
    return df.to_dict(orient="records")

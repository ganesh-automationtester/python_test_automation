
# Playwright + Python Automation Framework

Features:
- Page Object Model (POM)
- Data-driven tests (CSV / JSON / Excel)
- Allure + HTML reports
- Video recording for every test
- Screenshot on failure
- Parallel execution (xdist)
- Simple logging helpers & UI helpers

## 1) Setup
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install
```

## 2) Run
```bash
pytest
# or with explicit Allure dir
pytest --alluredir=allure-results
allure serve allure-results
```

## 3) Config
Edit values in `utils/config.py`. Defaults use Sauce Demo:
- URL: https://www.saucedemo.com/
- Valid login: standard_user / secret_sauce
- Invalid login cases are in testdata
```bash
# Parallel 2 workers by default via pytest.ini
```

## 4) Structure
See folders for tests, pages, utils, and testdata.

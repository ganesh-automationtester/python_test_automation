#### Local Commands

#####  --browser={chrome, firefox, edge}

```sh
pytest --browser=chrome --alluredir allure-results
pytest --browser=firefox --alluredir allure-results
pytest --browser=edge --alluredir allure-results

```

#### Run Regression Test Suites (Mark your test cases with test suites)
```sh
pytest -m regression --browser=chrome --alluredir allure-results
pytest -m regression --browser=firefox --alluredir allure-results
pytest -m regression--browser=edge --alluredir allure-results
```

#### Trigger Allure Reports

```sh
allure serve allure-results
```
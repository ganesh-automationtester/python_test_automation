#import allure
#import pyscreenrec
import pytest
#from allure_commons.types import AttachmentType
from selenium import webdriver
import constants
from utils.settings import GetUrl
from utils.custom_logger import CustomLogger
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.ie.service import Service as EdgeService
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager

log = CustomLogger.log()


@pytest.fixture(autouse=True)
def setup(request):
    #recorder = pyscreenrec.ScreenRecorder()
    op = webdriver.ChromeOptions()
    op.add_argument('headless')
    browser = request.config.getoption('browser')
    if browser.lower() == 'firefox':
        driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()))
        log.info('Firefox driver Initiated')
    elif browser.lower() == 'edge':
        driver = webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager().install()))
        log.info('Edge driver Initiated')
    else:
        driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
        log.info('Chrome driver Initiated')
    recording_path = "recording.mp4"
    #recorder.start_recording(recording_path, 10)
    driver.implicitly_wait(constants.IMPLICIT_WAIT)
    driver.maximize_window()
    driver.get(GetUrl.URL)
    driver.delete_all_cookies()
    request.cls.driver = driver
    before_failed = request.session.testsfailed
    yield
    log.info('Test Completed')
   # recorder.stop_recording()
   # with open(recording_path, 'rb') as video_file:
        #allure.attach(video_file.read(), name="Test Recording", attachment_type=allure.attachment_type.MP4)
    
    if request.session.testsfailed != before_failed:
        log.info('Test failed')
    else:
        log.info('Test passed')
    # if request.session.testsfailed != before_failed:
    #     # allure.attach(driver.get_screenshot_as_png(),
    #     #               name="Test failed", attachment_type=AttachmentType.PNG)
    #     allure.attach("recording.mp4", name="Test failed", attachment_type=AttachmentType.MP4)
    # else:
    #     # allure.attach(driver.get_screenshot_as_png(),
    #     #               name="Test passed", attachment_type=AttachmentType.PNG)
    #     allure.attach("recording.mp4", name="Test passed", attachment_type=AttachmentType.MP4)
    driver.quit()


def pytest_addoption(parser):
    parser.addoption("--browser", action="store", default="chrome")

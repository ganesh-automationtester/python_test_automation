import allure
import pytest

import constants
from pages.home_page import HomePage
from pages.login_page import LoginPage
from utils.custom_logger import CustomLogger
from utils.settings import Credentials
from utils.ui_helpers import UIHelpers


class Test_login:
    log = CustomLogger.log()

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.home_page = HomePage(self.driver)

    @pytest.mark.High
    @allure.description('Check login with valid credentials')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_login_valid_cred(self):
        self.login_page.login_to_dashboard()

    @pytest.mark.High
    @allure.description('Check login with invalid credentials')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_login_with_invalid_credentials(self):
        self.login_page.setUserName('ganesh@gmail.com')
        self.login_page.setPassword('12345')
        self.login_page.clickLogin()
        actual_text = self.login_page.getErrorDisplayMessage()
        expected_text = constants.DISPLAY_MSG_INVALID_CRED
        self.ui_helpers.verify_text_match(actual_text, expected_text)

    @pytest.mark.High
    @allure.description('Check login with empty username')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_login_with_empty_username(self):
        self.login_page.setPassword(Credentials.PASSWORD)
        self.login_page.clickLogin()
        actual_text = self.login_page.getErrorDisplayMessage()
        expected_text = constants.DISPLAY_MSG_EMPTY_USERNAME
        self.ui_helpers.verify_text_match(actual_text, expected_text)

    @pytest.mark.High
    @allure.description('Check login with empty password')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_login_with_empty_password(self):
        self.login_page.setUserName(Credentials.USERNAME)
        self.login_page.clickLogin()
        actual_text = self.login_page.getErrorDisplayMessage()
        expected_text = constants.DISPLAY_MSG_EMPTY_PASSWORD
        self.ui_helpers.verify_text_match(actual_text, expected_text)

    @pytest.mark.High
    @allure.description('Check login with empty username & password')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_login_with_empty_credentials(self):
        self.login_page.clickLogin()
        actual_text = self.login_page.getErrorDisplayMessage()
        expected_text = constants.DISPLAY_MSG_EMPTY_CRED
        self.ui_helpers.verify_text_match(actual_text, expected_text)

    @pytest.mark.High
    @allure.description('Check login when no access to user management')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_check_login_no_access_to_um(self):
        self.login_page.setUserName('ganeshdubbewar21@gmail.com')
        self.login_page.setPassword('Ganesh@1997')
        self.login_page.clickLogin()
        actual_text = self.ui_helpers.get_text_from_element("xpath",
                                                            self.home_page.locator_home_screen_display_msg_no_access)
        expected_text = constants.DISPLAY_MSG_HOME_PAGE_UM_NO_ACCESS
        self.ui_helpers.verify_text_match(actual_text, expected_text)

import time
import allure
import pytest
import constants
from pages.bulk_edit_page import BulkEditUser
from pages.create_user_page import CreateUserPage
from pages.home_page import HomePage
from pages.login_page import LoginPage
from utils import xlutils
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers
from utils.settings import Credentials



if Credentials.ENVIRONMENT == 'EU-QA':
    file_name = './test_data/User Management Test Data -EU.xlsx'
    bulk_edit_sheet = 'bulk'
    No_of_valid_scenario_for_bulk_edit = xlutils.getRowCount(file_name, bulk_edit_sheet)
else :
    file_name = './test_data/User Management Test Data.xlsx'
    bulk_edit_sheet = 'bulk'
    No_of_valid_scenario_for_bulk_edit = xlutils.getRowCount(file_name, bulk_edit_sheet)


class Test_Bulk_Edit_User:
    log = CustomLogger.log()

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.home_page = HomePage(self.driver)
        self.bulk_edit = BulkEditUser(self.driver)
        self.create_user = CreateUserPage(self.driver)

    @pytest.mark.High
    @allure.title('Check bulk user edit landing page')
    @allure.description('Check bulk user edit landing page')
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id('QA-T2102')
    @pytest.mark.regression
    def test_bulk_user_edit_landing_page(self):
        test_result = []
        self.login_page.login_to_dashboard()
        self.log.info('Selecting customer as Zenatix-Testing')
        self.home_page.select_options_from_dropdown_by_value('customer', 'Zenatix-Testing')
        self.home_page.click_apply_filter()
        self.log.info('clicked on apply filter')
        assert self.ui_helpers.is_element_present("xpath", "//table")
        self.log.info('Filter applied successfully')
        self.log.info('Selecting all users')
        self.home_page.select_all_users()
        self.home_page.click_bulk_edit()
        main_header_names = self.bulk_edit.get_main_header_names()
        self.log.info(main_header_names)
        self.log.info('Validating customer and site header and sub-headers')
        self.bulk_edit.select_type_of_customer_editing('existing')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(main_header_names[0], constants.CUSTOMER_SITE)} for {constants.CUSTOMER_SITE} header')
        self.create_user.select_customer('Zenatix-Testing')
        sites_sub_header_names = self.bulk_edit.get_sites_sub_header_names()
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(self.bulk_edit.get_customer_field_name(), constants.CUSTOMERS)} for {constants.CUSTOMERS} field')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(self.bulk_edit.get_site_field_name(), constants.SITES)} for {constants.SITES} field')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(sites_sub_header_names[0], constants.CUSTOMER)} for {constants.CUSTOMER} field')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(sites_sub_header_names[1], constants.ACCESS_TAG)} for {constants.ACCESS_TAG} field')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(sites_sub_header_names[2], constants.VALUE)} for {constants.VALUE} field')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(sites_sub_header_names[3], constants.SITE)} for {constants.SITE} field')
        self.log.info('Successfully validated customer and site header and sub-headers..Verified!')
        self.log.info('Validating application and permission groups header and sub-headers')
        self.bulk_edit.select_type_of_application_editing('existing')
        time.sleep(2)
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(main_header_names[1], constants.APPLICATION_PERMISSION_GROUP)} for {constants.APPLICATION_PERMISSION_GROUP} header')
        application_permission_group_header_names = self.bulk_edit.get_application_and_permission_group_header_names()
        self.log.info(application_permission_group_header_names)
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_permission_group_header_names[0], constants.APPLICATION)} for {constants.APPLICATION} sub-header')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_permission_group_header_names[1], constants.PERMISSION_GROUP)} for {constants.PERMISSION_GROUP} sub-header')
        application_names = self.bulk_edit.get_application_names()
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[0], constants.ADMIN_DASHBOARD)} for {constants.ADMIN_DASHBOARD}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[1], constants.ALARM_MANAGEMENT)} for {constants.ALARM_MANAGEMENT}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[2], constants.USER_MANAGEMENT)} for {constants.USER_MANAGEMENT}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[3], constants.CUSTOMER_DASHBOARD)} for {constants.CUSTOMER_DASHBOARD}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[4], constants.DEVICE_MANAGEMENT)} for {constants.DEVICE_MANAGEMENT}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[5], constants.SCHEDULE_DASHBOARD)} for {constants.SCHEDULE_DASHBOARD}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[6], constants.CLIENT_APP)} for {constants.CLIENT_APP}')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(application_names[7], constants.MAKER_SUITE)} for {constants.MAKER_SUITE}')
        self.ui_helpers.scroll_into_element("xpath", self.bulk_edit.locator_save_button)
        permission_groups = self.bulk_edit.get_permission_group_names()
        self.log.info(permission_groups)
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(permission_groups[0], constants.BASIC)} for {constants.BASIC} permission group')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(permission_groups[1], constants.INTERMEDIATE)} for {constants.INTERMEDIATE} permission group')
        #test_result.append(
           # f'{self.ui_helpers.get_assertion_result(permission_groups[2], constants.INTERMEDIATE2)} for {constants.INTERMEDIATE2} permission group')
        test_result.append(
            f'{self.ui_helpers.get_assertion_result(permission_groups[2], constants.ADVANCED)} for {constants.ADVANCED} permission group')
        self.log.info('Successfully validated application and permission groups header and sub-headers..Verified!')
        self.ui_helpers.log_test_result(test_result)
        self.log.info('Verifying information message')
        self.log.info(self.bulk_edit.get_information_message())
        self.ui_helpers.verify_text_match(self.bulk_edit.get_information_message(), constants.BULK_EDIT_INFORMATION_MSG)
        self.log.info('Verified information message')
        self.log.info('Verifying Save and Cancel button')
        assert self.ui_helpers.is_element_present("xpath", self.bulk_edit.locator_save_button)
        assert self.ui_helpers.is_element_present("xpath", self.bulk_edit.locator_cancel_button)
        self.log.info('Verified Save and Cancel button')

    @pytest.mark.High
    @allure.title('Check bulk edit')
    @allure.description('Check bulk edit')
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id('QA-T2100')
    @pytest.mark.regression
    @pytest.mark.parametrize('scenario', range(1, No_of_valid_scenario_for_bulk_edit))
    #@pytest.mark.parametrize('scenario', range(1, 2))
    def test_check_bulk_user_edit(self,scenario):
        row_no = int(scenario)
        self.login_page.login_to_dashboard()
        self.log.info('Selecting customer as Zenatix-Testing from customer dropdown')
        self.home_page.select_options_from_dropdown_by_value('customer', 'Zenatix-Testing')
        self.home_page.click_apply_filter()
        self.log.info('clicked on apply filter')
        assert self.ui_helpers.is_element_present("xpath", "//table")
        self.log.info('Filter applied successfully')
        self.home_page.search_user_by_username('name')
        self.home_page.click_search_button()
        self.log.info('Users searched using search box')
        self.home_page.select_all_users()
        self.log.info('Selecting all users')
        self.home_page.click_bulk_edit()
        self.log.info('Clicked on bulk edit')
        customer_editing_choice = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 1)
        customer_name = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 2)
        access_tag = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 3)
        access_tag_value = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 4)
        application_permission_choice = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 5)
        application_name = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 6)
        permission_name = xlutils.readData(file_name, bulk_edit_sheet, 1 + row_no, 7)
        if customer_editing_choice is not None:
            self.bulk_edit.select_type_of_customer_editing(customer_editing_choice)
            self.log.info(f'Selecting customer as {customer_name}')
            self.create_user.select_customer(customer_name)
            self.log.info(f'Selecting access_tag as {access_tag}')
            self.bulk_edit.select_access_tag(access_tag)
            self.log.info(f'Selecting access_tag_value as {access_tag_value}')
            self.bulk_edit.select_access_tag_value(access_tag_value)
        else:
            self.log.info('customer selection not given')
        self.ui_helpers.scroll_into_element("xpath", self.bulk_edit.locator_save_button)
        if application_permission_choice is not None:
            self.bulk_edit.select_type_of_application_editing(application_permission_choice)
            if application_name is None or permission_name is None:
                self.log.info('No application and permission group selected')
            elif ',' in application_name:
                application_loop = application_name.split(',')
                permission_loop = permission_name.split(',')
                for application, permission in zip(application_loop, permission_loop):
                    self.create_user.select_application_and_permission_group(application, permission)
                    self.log.info(f"Selected application and permission group details {application, permission}")
            else:
                self.create_user.select_application_and_permission_group(application_name, permission_name)
                self.log.info(f"Selected application and permission group details {application_name, permission_name}")
        else:
            self.log.info('application and permission selection not given')
        self.log.info('Saving changes')
        self.bulk_edit.click_save()
        self.log.info('Validating confirmation prompt message')
        self.ui_helpers.verify_text_match(self.bulk_edit.get_confirmation_prompt_message(),
                                          constants.BULK_EDIT_CONFIRMATION_PROMPT_MSG)
        self.log.info('Accepting confirmation prompt')
        self.bulk_edit.accept_confirmation_prompt('Yes')
        self.ui_helpers.verify_text_match(self.login_page.getToastMessage(), constants.BULK_EDIT_SUCCESS_TOAST_MSG)
        
        
        
    
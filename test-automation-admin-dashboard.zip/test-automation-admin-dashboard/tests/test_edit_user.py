import allure
import pytest
from pages.create_user_page import CreateUserPage
from pages.edit_page import EditUserPage
from pages.home_page import HomePage
from pages.login_page import LoginPage
from pages.view_page import ViewUserPage
from utils import xlutils
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


file_name = './test_data/User Management Test Data.xlsx'
sheet_name = 'edit data'
No_of_valid_scenario = xlutils.getRowCount(file_name, sheet_name)


class Test_Edit_User_Page:
    log = CustomLogger.log()

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.view_page = ViewUserPage(self.driver)
        self.edit_page = EditUserPage(self.driver)
        self.create_user_page = CreateUserPage(self.driver)
        self.home_page = HomePage(self.driver)


    @allure.title("Edit User Feature for the first name, last name and middle name")
    @allure.description("Scenario for the Edit button for the first name, last name and middle name")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id("QA-T1591")
    @pytest.mark.parametrize('scenario', range(1, 4))
    def test_edit_names_details(self, scenario):
        row_no = int(scenario)
        self.login_page.login_to_dashboard()
        first_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 1)
        middle_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 2)
        last_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 3)
        email = xlutils.readData(file_name, sheet_name, 1 + row_no, 4)
        expected_text = xlutils.readData(file_name, sheet_name, 1 + row_no, 15)
        self.home_page.search_user_by_username(email)
        self.home_page.click_search_button()
        self.home_page.click_menu()
        self.home_page.click_edit_user_details_button()
        self.log.info('Edit button clicked')
        self.ui_helpers.verify_text_contains(self.edit_page.get_edit_page_header_name(), 'Edit User -')
        self.log.info(f'Edit page opened for the user {email}')
        self.edit_page.edit_first_name(first_name)
        self.log.info(f'First name value has been edited to {first_name}')
        self.edit_page.edit_middle_name(middle_name)
        self.log.info(f'Middle name value has been edited to {middle_name}')
        self.edit_page.edit_last_name(last_name)
        self.log.info(f'Last name value has been edited to {last_name}')
        self.create_user_page.click_save_button()
        self.ui_helpers.verify_text_match(self.login_page.getToastMessage(), expected_text)
        self.log.info('User edited successfully......Verified for first, middle, last names')

    @allure.title("Edit User Feature for the email id and phone number")
    @allure.description("Scenario for the Edit button for the email id and phone number")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id("QA-T1591")
    @pytest.mark.parametrize('scenario', range(4, 6))
    def test_edit_email_phone(self, scenario):
        row_no = int(scenario)
        self.login_page.login_to_dashboard()
        phone_number = xlutils.readData(file_name, sheet_name, 1 + row_no, 6)
        email = xlutils.readData(file_name, sheet_name, 1 + row_no, 4)
        edited_text = xlutils.readData(file_name, sheet_name, 1 + row_no, 16)
        expected_text = xlutils.readData(file_name, sheet_name, 1 + row_no, 15)
        self.home_page.search_user_by_username(edited_text)
        self.home_page.click_search_button()
        self.home_page.click_menu()
        self.home_page.click_edit_user_details_button()
        self.log.info('Edit button clicked')
        self.ui_helpers.verify_text_contains(self.edit_page.get_edit_page_header_name(), 'Edit User -')
        self.log.info(f'Edit page opened for the user {edited_text}')
        self.edit_page.edit_email(email)
        self.log.info(f'Email value has been edited to {email}')
        self.edit_page.edit_phone_number(phone_number)
        self.log.info(f'Phone number value has been edited to {phone_number}')
        self.create_user_page.click_save_button()
        self.ui_helpers.verify_text_match(self.login_page.getToastMessage(), expected_text)
        self.log.info('User edited successfully......Verified for phone and number')

    @allure.title("Edit User Feature for the customer, access tag, access tag")
    @allure.description("Scenario for the Edit button for the customer, access tag, access tag")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id("QA-T1591")
    @pytest.mark.parametrize('scenario', range(6, 8))
    def test_edit_customer_access_tag_value(self, scenario):
        row_no = int(scenario)
        self.login_page.login_to_dashboard()
        email = xlutils.readData(file_name, sheet_name, 1 + row_no, 4)
        expected_text = xlutils.readData(file_name, sheet_name, 1 + row_no, 15)
        name_of_customer = xlutils.readData(file_name, sheet_name, 1 + row_no, 7)
        access_tag_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 8)
        access_tag_value_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 9)
        self.home_page.search_user_by_username(email)
        self.home_page.click_search_button()
        self.home_page.click_menu()
        self.home_page.click_edit_user_details_button()
        self.log.info('Edit button clicked')
        self.ui_helpers.verify_text_contains(self.edit_page.get_edit_page_header_name(), 'Edit User -')
        self.log.info(f'Edit page opened for the user {email}')
        if name_of_customer is not None:
            self.edit_page.edit_customer(name_of_customer)
            self.log.info(f'Customer name edited to {name_of_customer}')
        else:
            self.log.info('Customer not given')
            self.log.info(f'access tag :{access_tag_name}')
        if access_tag_name is None:
            self.log.info('Access Tag already selected')
            if ',' in access_tag_value_name:
                value_loop = access_tag_value_name.split(',')
                for value in value_loop:
                    self.edit_page.edit_access_tag_value(value)
                    self.log.info(f"Access tag values edited to {value}")
            else:
                self.edit_page.edit_access_tag_value(access_tag_value_name)
                self.log.info(f"Access tag values edited to {access_tag_value_name}")
        else:
            self.create_user_page.select_access_tag(access_tag_name)
            self.log.info(f'Access Tag edited to {access_tag_name}')
            if ',' in access_tag_value_name:
                value_loop = access_tag_value_name.split(',')
                for value in value_loop:
                    self.create_user_page.select_access_tag_value(value)
                    self.log.info(f'Access Tag value edited to {value}')
            else:
                self.create_user_page.select_access_tag_value(access_tag_value_name)
                self.log.info(f'Access Tag value edited to {access_tag_value_name}')
        self.create_user_page.click_save_button()
        self.ui_helpers.verify_text_match(self.login_page.getToastMessage(), expected_text)
        self.log.info('User edited successfully......Verified for the customer, access tag and access tag value')

    @allure.title("Edit User Feature for the application and permission group")
    @allure.description("Scenario for the Edit button for the application and permission group")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id("QA-T1591")
    @pytest.mark.parametrize('scenario', range(8, 9))
    def test_edit_application_permission(self, scenario):
        row_no = int(scenario)
        self.login_page.login_to_dashboard()
        email = xlutils.readData(file_name, sheet_name, 1 + row_no, 4)
        expected_text = xlutils.readData(file_name, sheet_name, 1 + row_no, 15)
        application_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 10)
        permission_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 11)
        self.home_page.search_user_by_username(email)
        self.home_page.click_search_button()
        self.home_page.click_menu()
        self.home_page.click_edit_user_details_button()
        self.log.info('Edit button clicked')
        self.ui_helpers.verify_text_contains(self.edit_page.get_edit_page_header_name(), 'Edit User -')
        self.log.info(f'Edit page opened for the user {email}')
        if ',' in application_name:
            application_name_list = application_name.split(',')
            permission_name_list = permission_name.split(',')
            for value1, value2 in zip(application_name_list, permission_name_list):
                self.create_user_page.select_application_and_permission_group(value1, value2)
                self.log.info(f'Application and permission group edited to {value1, value2}')
        else:
            self.create_user_page.select_application_and_permission_group(application_name, permission_name)
            self.log.info(f'Application and permission group edited to {application_name, permission_name}')
        self.create_user_page.click_save_button()
        self.ui_helpers.verify_text_contains(self.login_page.getToastMessage(), expected_text)
        self.log.info('User edited successfully......Verified for the application and permission group')

    @allure.title("Edit User Feature for the language selection")
    @allure.description("Scenario for the Edit button for the language selection")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id("QA-T1591")
    @pytest.mark.parametrize('scenario', range(9, No_of_valid_scenario))
    def test_edit_language_notification_unit(self, scenario):
        row_no = int(scenario)
        self.login_page.login_to_dashboard()
        email = xlutils.readData(file_name, sheet_name, 1 + row_no, 4)
        expected_text = xlutils.readData(file_name, sheet_name, 1 + row_no, 15)
        language_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 12)
        notification_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 13)
        unit_name = xlutils.readData(file_name, sheet_name, 1 + row_no, 14)
        self.home_page.search_user_by_username(email)
        self.home_page.click_search_button()
        self.home_page.click_menu()
        self.home_page.click_edit_user_details_button()
        self.log.info('Edit button clicked')
        self.ui_helpers.verify_text_contains(self.edit_page.get_edit_page_header_name(), 'Edit User -')
        self.log.info(f'Edit page opened for the user {email}')
        if language_name is not None:
            self.create_user_page.select_language(language_name)
        self.log.info(f"Selected language is {language_name}")
        if notification_name is not None:
            self.create_user_page.select_notification(notification_name)
        self.log.info(f"Selected language is {notification_name}")
        if unit_name is not None:
            self.create_user_page.select_language(unit_name)
        self.log.info(f"Selected language is {unit_name}")
        self.create_user_page.click_save_button()
        self.ui_helpers.verify_text_contains(self.login_page.getToastMessage(), expected_text)
        self.log.info("user edited successfully........Verified for the language preference")

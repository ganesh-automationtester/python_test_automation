import allure
from pages.bulk_edit_page import BulkEditUser
import pytest

from pages.bulk_edit_page import BulkEditUser
from pages.bulk_user_creation_page import BulkCreateUser
from pages.create_user_page import CreateUserPage
from pages.home_page import HomePage
from pages.login_page import LoginPage
from utils import xlutils
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers
from utils.settings import Credentials


if Credentials.ENVIRONMENT == 'EU-QA':
    test_scenarios = './test_data/Test Data - Bulk User Creation - EU.xlsx'
    sheet_name = 'Test Scenario'
    no_of_scenario = xlutils.getRowCount(test_scenarios, sheet_name)
    get_list_of_scenario = xlutils.get_list_of_scenario(test_scenarios, sheet_name, 1)
else :
    test_scenarios = './test_data/Test Data - Bulk User Creation.xlsx'
    sheet_name = 'Test Scenario'
    no_of_scenario = xlutils.getRowCount(test_scenarios, sheet_name)
    get_list_of_scenario = xlutils.get_list_of_scenario(test_scenarios, sheet_name, 1)




class Test_bulk_user_create:
    log = CustomLogger.log()

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.home_page = HomePage(self.driver)
        self.create_user = CreateUserPage(self.driver)
        self.bulk_create = BulkCreateUser(self.driver)
        self.bulk_edit = BulkEditUser(self.driver)


    @pytest.mark.High
    @allure.title('Check bulk user creation')
    @allure.description('Check bulk user creation')
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id('QA-T1793')
    @pytest.mark.regression
    @pytest.mark.parametrize(f'index, scenario', enumerate(get_list_of_scenario))
    def test_check_bulk_user_creation(self, index, scenario):
        row_no = index + 1
        self.login_page.login_to_dashboard()
        self.home_page.click_add_user()
        self.bulk_create.click_bulk_create_button()
        if row_no == 2:
            self.bulk_create.click_download_template()
        file_location = xlutils.readData(test_scenarios, sheet_name, row_no + 1, 2)
        expected_toast_message = xlutils.readData(test_scenarios, sheet_name, row_no + 1, 3)
        assert self.ui_helpers.is_element_clickable("xpath", self.bulk_create.locator_upload_button)
        self.bulk_create.upload_file(file_location)
        self.bulk_create.click_next_button()
        self.bulk_edit.accept_confirmation_prompt('Yes')
        actual_toast_message = self.login_page.getToastMessage()
        self.log.info(actual_toast_message)
        self.ui_helpers.verify_text_match(actual_toast_message, expected_toast_message)



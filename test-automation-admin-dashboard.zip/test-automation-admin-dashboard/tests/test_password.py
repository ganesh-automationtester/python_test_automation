import time
import allure # type: ignore
from pages.reset_password_page import ResetPasswordPage
import pytest # type: ignore

import constants
from pages.create_user_page import CreateUserPage
from pages.home_page import HomePage
from pages.login_page import LoginPage
from pages.view_page import ViewUserPage
from utils import xlutils
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers




class Test_Reset_Password:
    log = CustomLogger.log()

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.home_page = HomePage(self.driver)
        self.create_user = CreateUserPage(self.driver)
        self.view_page = ViewUserPage(self.driver)
        self.reset_password_page = ResetPasswordPage(self.driver)

    @allure.title("Reset Password Functionality")
    @allure.description("Reset Password, click on privacy policy")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id("QA-T1582")
    def test_reset_password(self):
        self.login_page.login_to_dashboard()
        time.sleep(2)
        self.home_page.click_logout()
        time.sleep(2)
        self.reset_password_page.click_reset_password_btn()
        time.sleep(2)
        #self.ui_helpers.verify_text_match('Generate/Change Password', self.reset_password_page.get_reset_password_heading)
        self.reset_password_page.enter_username('rashi.kthv.3012@gmail.com')
        time.sleep(2)
        self.reset_password_page.enter_password('Zen@1234')
        time.sleep(2)
        self.reset_password_page.re_enter_password('Zen@1234')
        time.sleep(2)
        self.reset_password_page.click_next_btn()
        time.sleep(2)






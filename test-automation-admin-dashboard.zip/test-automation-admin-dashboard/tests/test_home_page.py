import time
import allure
import pytest
import constants
from pages.home_page import HomePage
from pages.login_page import LoginPage
from pages.view_page import ViewUserPage
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class Test_Home_Page:
    log = CustomLogger.log()

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.home_page = HomePage(self.driver)
        self.view_page = ViewUserPage(self.driver)

    @pytest.mark.High
    @allure.title('Check enable/disable user')
    @allure.description('Check enable/disable user')
    @allure.severity(allure.severity_level.NORMAL)
    @allure.id('QA-T1592')
    @pytest.mark.regression
    @pytest.mark.parametrize("parameter", range(2))
    def test_enable_disable_user(self, parameter):
        expected_status = ''
        username = "rashi.kthv.3012@gmail.com"
        self.login_page.login_to_dashboard()
        self.home_page.search_user_by_username(username)
        self.home_page.click_search_button()
        actual_username = self.home_page.get_username()
        self.ui_helpers.verify_text_match(actual_username, username)
        self.home_page.select_user()
        self.log.info(f'{username} user is selected successfully.')
        if self.home_page.get_status_of_selected_user() == constants.ENABLED_USER_STATUS:
            self.home_page.click_disable()
            self.home_page.accept_confirmation_prompt()

            self.ui_helpers.verify_text_match(self.login_page.getToastMessage(),
                                              constants.TOAST_USER_DISABLE)
            self.log.info(f'{username} user is disabled successfully.')
            expected_status = constants.DISABLED_USER_STATUS
        elif self.home_page.get_status_of_selected_user() == constants.DISABLED_USER_STATUS:
            self.home_page.click_enable()
            time.sleep(5)
            expected_status = constants.ENABLED_USER_STATUS
            self.ui_helpers.verify_text_match(self.login_page.getToastMessage(),
                                              constants.TOAST_USER_ENABLE)
            self.log.info(f'{username} user is enabled successfully.')
        self.home_page.search_user_by_username(username)
        self.home_page.click_search_button()
        actual_status = self.home_page.get_status_of_selected_user()
        self.ui_helpers.verify_text_match(actual_status, expected_status)
        self.home_page.click_logout()
        self.login_page.setUserName(username)
        self.login_page.setPassword('Zen@1234')
        self.login_page.clickLogin()
        if actual_status == constants.DISABLED_USER_STATUS:
            expected_text = constants.DISPLAY_MSG_USER_DISABLED
            actual_text = self.login_page.getErrorDisplayMessage()
            self.ui_helpers.verify_text_match(actual_text, expected_text)
        else:
            actual_text = self.ui_helpers.get_text_from_element("xpath",
                                                                self.home_page.locator_home_screen_display_msg_no_access)
            expected_text = constants.DISPLAY_MSG_HOME_PAGE_UM_NO_ACCESS
            self.ui_helpers.verify_text_match(actual_text, expected_text)
        time.sleep(5)

    @pytest.mark.High
    @allure.title('Check filters')
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description('Check search user functionality')
    @allure.id('QA-T1595')
    @pytest.mark.regression
    @pytest.mark.parametrize("scenario", ["valid_username", "invalid_username"])
    def test_search_user_by_username(self, scenario):
        valid_username = "rashi.kthv.3012@gmail.com"
        self.login_page.login_to_dashboard()
        if scenario == "invalid_username":
            self.log.info('Checking search users with invalid username')
            invalid_username = "rashitest@gmail.com"
            self.home_page.search_user_by_username(invalid_username)
            self.home_page.click_search_button()
            assert (self.ui_helpers.get_text_from_element("xpath", "//tbody//tr//td")
                    == constants.DISPLAY_MSG_NO_RESULT_FOUND), 'Test Failed'
            self.log.info(f'Admin is getting display message as {constants.DISPLAY_MSG_NO_RESULT_FOUND}')
        else:
            self.log.info('Checking search users with valid username')
            self.home_page.search_user_by_username(valid_username)
            self.home_page.click_search_button()
            assert self.home_page.get_username() == valid_username, 'Test Failed'
            self.log.info(f'User searched successfully')

    @pytest.mark.High
    @allure.severity(allure.severity_level.NORMAL)
    @allure.title('Check reset filter functionality')
    @allure.description('Check reset filter functionality')
    @allure.id('QA-T1595')
    @pytest.mark.regression
    def test_check_reset_filter(self):
        valid_username = "rashi.kthv.3012@gmail.com"
        self.login_page.login_to_dashboard()
        assert self.ui_helpers.is_element_present("xpath", self.home_page.locator_reset_button_disabled)
        self.log.info('When no filter is selected reset button is disabled')
        self.home_page.search_user_by_username(valid_username)
        self.home_page.click_search_button()
        self.log.info('Searching user with valid username')
        assert self.home_page.get_username() == valid_username
        self.log.info(f'User searched successfully')
        self.home_page.click_reset_button()
        self.log.info('Clicked on reset button')
        assert self.ui_helpers.is_element_present("xpath", self.home_page.locator_reset_button_disabled)
        actual_text = self.ui_helpers.get_text_from_element("xpath", self.home_page.locator_home_screen_display_msg)
        self.ui_helpers.verify_text_contains(actual_text, constants.DISPLAY_MSG_HOME_PAGE_UM)
        self.log.info('Reset filter functionality is working as expected')

    @pytest.mark.High
    @allure.severity(allure.severity_level.NORMAL)
    @allure.title('Check filters')
    @allure.description('Check filters')
    @allure.id('QA-T1595')
    @pytest.mark.regression
    def test_check_filters(self):
        self.login_page.login_to_dashboard()
        customer = 'Zenatix-Testing'
        site = 'Zenatix-Testing-QA'
        status = 'Enable'
        permission_group = 'Advanced'
        application = 'Schedules dashboard'
        self.home_page.select_options_from_dropdown_by_value('customer', customer)
        self.home_page.select_options_from_dropdown_by_value('site', site)
        self.home_page.select_options_from_dropdown_by_value('status', status)
        self.home_page.select_options_from_dropdown_by_value('permission group', permission_group)
        self.home_page.select_options_from_dropdown_by_value('application', application)
        self.home_page.click_apply_filter()
        self.ui_helpers.verify_text_match(self.home_page.get_status_of_selected_user(), 'active')
        self.home_page.click_menu()
        self.ui_helpers.verify_text_match(self.view_page.get_customer_name(), customer)
        self.log.info(self.view_page.get_application())
        if application in self.view_page.get_application():
            assert True
        elif permission_group in self.view_page.get_permission_group():
            assert True, self.log.info('Filters are not working correctly')
        else:
            self.log.info('Filters are not working correctly')
            assert False, 'Filters are not working correctly'

    @pytest.mark.High
    @allure.severity(allure.severity_level.NORMAL)
    @allure.title('Check landing screen of User Management')
    @allure.description('Check landing screen of User Management')
    @allure.id('QA-T1581')
    @pytest.mark.regression
    def test_check_home_page_landing_screen(self):
        self.login_page.login_to_dashboard()
        self.log.info('Validating logo, logo name and profile button')
        self.log.info(self.ui_helpers.get_attribute_value_from_element("xpath", self.home_page.locator_logo, 'alt'))
        self.ui_helpers.verify_text_match(self.ui_helpers.get_attribute_value_from_element("xpath",
                                                                                           self.home_page.locator_logo,
                                                                                           'alt'),
                                          constants.ZENATIX_LOGO_ATTRIBUTE_VALUE)
        #self.ui_helpers.verify_text_match(self.ui_helpers.get_text_from_element("xpath",
                                                                                #self.home_page.locator_logo_name),
                                          #constants.ZENATIX_LOGO_NAME)
        self.ui_helpers.is_element_present("xpath", self.home_page.locator_click_profile)
        self.log.info('Logo, logo name and profile button is present..Verified!')
        self.log.info('Validating display message')
        actual_display_msg = self.ui_helpers.get_text_from_element("xpath",
                                                                   self.home_page.locator_home_screen_display_msg)
        self.ui_helpers.verify_text_contains(actual_display_msg, constants.DISPLAY_MSG_HOME_PAGE_UM)
        self.log.info('Display message is present..Verified!')
        self.log.info('Validating search box, search button and add user button')
        assert self.ui_helpers.is_element_present("xpath", self.home_page.locator_search_user_input_box)
        assert self.ui_helpers.is_element_present("xpath", self.home_page.locator_search_button)
        assert self.ui_helpers.is_element_present("xpath", self.home_page.locator_click_add_user)
        self.log.info('Search box, search button and add user button is present..Verified!')
        self.log.info('Validating all filters dropdown present')
        filters_field_name = []
        dropdown_elements_list = len(self.ui_helpers.get_element_list("xpath", self.home_page.locator_list_dropdown))
        for filter_name in range(1, dropdown_elements_list + 1):
            filter_name_value = self.ui_helpers.get_text_from_element("xpath",
                                                                      f"{self.home_page.locator_list_dropdown}[{filter_name}]")
            filters_field_name.append(filter_name_value)
        assert filters_field_name[0] == constants.CUSTOMER
        assert filters_field_name[1] == constants.SITE
        assert filters_field_name[2] == constants.STATUS
        assert filters_field_name[3] == constants.PERMISSION_GROUP
        assert filters_field_name[4] == constants.APPLICATION
        self.log.info('All filters dropdown are present..Verified!')
        self.log.info('Check side pane functionality(Hide/Show)')
        self.home_page.click_hide_side_pane()
        assert self.ui_helpers.is_element_present("xpath", self.home_page.locator_side_pane_hidden)
        self.home_page.click_open_side_pane()
        assert self.ui_helpers.verify_element_not_present("xpath", self.home_page.locator_side_pane_hidden)
        self.log.info('Side pane functionality is working fine..Verified!')
        self.log.info('Verifying table headers')
        self.home_page.search_user_by_username("rashi.kthv.3012@gmail.com")
        self.home_page.click_search_button()
        expected_text = self.ui_helpers.get_text_from_element("xpath",
                                                              self.home_page.locator_get_header_value_username)
        self.ui_helpers.verify_text_match(expected_text, constants.USERNAME)
        expected_text = self.ui_helpers.get_text_from_element("xpath",
                                                              self.home_page.locator_get_header_value_status)
        self.ui_helpers.verify_text_match(expected_text, constants.STATUS)
        self.log.info('Table headers are as expected..Verified!')
      

# Use this section to define waits

IMPLICIT_WAIT = 10
EXPLICIT_WAIT = 10
MIN_TIME_OUT = 10
MAX_TIME_OUT = 10

# Use this section to store all warning, error, success toast messages & display messages
TOAST_INVALID_OTP = "Please check OTP"
TOAST_OTP_SENT = "OTP sent successfully"
TOAST_USER_ENABLE = "user enabled successfully"
TOAST_USER_DISABLE = "user disabled successfully"
DISPLAY_MSG_EMPTY_PASSWORD = "Password can't be empty"
DISPLAY_MSG_EMPTY_USERNAME = "Username can't be empty"
DISPLAY_MSG_INVALID_CRED = "Username or password is incorrect"
DISPLAY_MSG_EMPTY_CRED = "Username and password can't be empty"
DISPLAY_MSG_USER_DISABLED = "User is disabled. Please contact admin."
DISPLAY_MSG_HOME_PAGE_UM = "Use search or filters to find user configurations"
DISPLAY_MSG_HOME_PAGE_UM_NO_ACCESS = "You do not have permission for this."
DISPLAY_MSG_HOME_PAGE_AM = "Use search or filters to find alarm configurations"
ENABLED_USER_STATUS = 'Active'
DISABLED_USER_STATUS = 'Inactive'
DISPLAY_MSG_NO_RESULT_FOUND = 'No results found.'
DISPLAY_MSG_NO_PERMISSION = 'You do not have permission for this.'
ZENATIX_LOGO_NAME = 'Zenatix Administration'
TOAST_USER_CREATED_SUCCESSFULLY = 'User created successfully, verification pending.'
DISPLAY_MSG_FIRST_NAME_ERROR = "This field cannot contain more than 30 characters."
DISPLAY_MSG_LAST_NAME_ERROR_NAME_ERROR = "This field cannot contain more than 30 characters."
DISPLAY_MSG_FIRST_NAME_EMPTY = "Please input your first name"
DISPLAY_MSG_LAST_NAME_EMPTY = "Please input your last name"
DISPLAY_MSG_LAST_NAME_ERROR = "This field cannot contain more than 30 characters."
DISPLAY_MSG_EMAIL_ERROR = "Please enter a valid email to continue."
DISPLAY_MSG_EMAIL_ALREADY_PRESENT = "Email already present, please enter a different one"
DISPLAY_MSG_PHONE_NUMBER_ERROR = "Please enter a valid phone number to continue"
DISPLAY_MSG_PHONE_NUMBER_ALREADY_PRESENT = "Phone number already present, please enter a different one"
BULK_EDIT_INFORMATION_MSG = "Upon selecting 'add to existing' the customer and sites that are selected will be added to the list of customers and sites that are accessible to the user."
BULK_EDIT_CONFIRMATION_PROMPT_MSG = "Are you sure you want to make these changes?"
BULK_EDIT_FAIL_TOAST_MSG = "Unable to edit the user having higher permission group"
BULK_EDIT_SUCCESS_TOAST_MSG = "10 user edited successfully!"
DISPLAY_ERROR_CUSTOMER = "Please select atleast one access tag."
TOAST_USER_EDITED_SUCCESSFULLY = "User updated successfully, verification pending."
TOAST_NO_PERMISSION = "No permission to enable the user"

# Miscellaneous

DISABLE_DROPDOWN_ATTRIBUTE_VALUE = "disable-dropdown"
ENABLE_DROPDOWN_ATTRIBUTE_VALUE = "ant-dropdown-trigger"
ZENATIX_LOGO_ATTRIBUTE_VALUE = 'zenatixLogo'


# Filter names
CUSTOMER = 'Customer'
SITE = 'Site'
STATUS = 'Status'
PERMISSION_GROUP = 'Permission Group'
APPLICATION = 'Application'

# Users table header values

USERNAME = 'User Name'

# User creation form fields name
# Main headers
BASIC_DETAIL = 'Basic Details'
CUSTOMER_SITE = 'Customer & Sites'
APPLICATION_PERMISSION_GROUP = 'Application & Permission Group'
# Sub-Headers
FIRST_NAME = 'First Name'
MIDDLE_NAME = 'Middle Name'
LAST_NAME = 'Last Name'
EMAIL = 'E-mail'
PHONE_NO = 'Phone Number'
CUSTOMERS = 'Customers'
SITES = 'Sites'
ACCESS_TAG = 'Access Tag'
VALUE = 'Value'
ADMIN_DASHBOARD = 'Admin Dashboard'
ALARM_MANAGEMENT = 'Alarms Management'
USER_MANAGEMENT = 'User Management'
CUSTOMER_DASHBOARD = 'Customer Dashboard'
DEVICE_MANAGEMENT = 'Device Management'
SCHEDULE_DASHBOARD = 'Schedules Dashboard'
CLIENT_APP = 'Client Mobile App'
MAKER_SUITE = 'Makersuite Dashboard'
PARTNER_PORTAL = 'Partner Portal'
BASIC = 'Basic'
INTERMEDIATE = 'Intermediate'
ADVANCED = 'Advanced'
INTERMEDIATE2 ='Intermediate+'

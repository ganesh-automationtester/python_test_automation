"""
This module contains most of the reusable functions to support test cases.
"""

import os
import time
import string
from traceback import print_stack
#import pyscreenrec
#from PIL.Image import core as image
from selenium.common.exceptions import StaleElementReferenceException, ElementClickInterceptedException
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys

import constants
from utils.custom_logger import CustomLogger
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import random
from faker import Faker

log = CustomLogger.log()
faker = Faker()


class UIHelpers:
    """
    UI Helpers class to contains all ui helper methods.
    """

    def __init__(self, driver):
        self.driver = driver

    def get_title(self):

        """
        This method is used for getting the page title.
        :return: this method returns page title.
        """
        page_title = ""
        try:
            page_title = self.driver.title
            if page_title is None:
                log.error("Page title value is empty.")
        except:
            log.error("Exception occurred while retrieving the page title.")

        return page_title

    @staticmethod
    def get_locator_type(locator_type):

        """
        This method is used for getting locator type for element
        :param locator_type: it takes the locator type parameter ex- xpath, id
        :return: it returns the element identification based on locator type
        """

        try:
            locator_type = locator_type.lower()

            if locator_type == "id":
                return By.ID
            elif locator_type == "xpath":
                return By.XPATH
            elif locator_type == "name":
                return By.NAME
            elif locator_type == "class":
                return By.CLASS_NAME
            elif locator_type == "link":
                return By.LINK_TEXT
            elif locator_type == "partial link":
                return By.PARTIAL_LINK_TEXT
        except:
            log.error(f"Locator Type {locator_type} is not listed.")

    def wait_for_element_to_be_present(self, locator_type, locator_properties):

        """
        This function is used for explicit waits till element present
        :param locator_type: it takes locator type as parameter
        :param locator_properties: it takes locator string as parameter
        :return: it returns the boolean value according to the element located or not
        """
        element = (self.get_locator_type(locator_type), locator_properties)
        try:
            WebDriverWait(self.driver, constants.EXPLICIT_WAIT).until(
                EC.presence_of_element_located(element))
            return True
        except:
            return False

    # need to check this method
    def wait_for_element_to_be_clickable(self, locator_type, locator_properties):

        """
        This function is used for explicit waits till element clickable
        :param locator_type: it takes locator type as parameter
        :param locator_properties: it takes locator string as parameter
        :return: it returns the boolean value according to the element located or not
        """
        element = (self.get_locator_type(locator_type), locator_properties)
        try:
            WebDriverWait(self.driver, constants.EXPLICIT_WAIT).until(
                EC.element_to_be_clickable(element))
            return True
        except:
            log.error("Exception occurred while waiting for element to be clickable.")
            return False

    def wait_for_element_to_be_displayed(self, locator_properties, locator_type,
                                         max_time_out=constants.MIN_TIME_OUT):

        """
        This function is used for explicit waits till element displayed
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :param max_time_out: this is the maximum time to wait for particular element
        :return: it returns the boolean value according to the element located or not
        """

        try:
            WebDriverWait(self.driver, max_time_out, ignored_exceptions=[StaleElementReferenceException]).until(
                EC.visibility_of_element_located((self.get_locator_type(locator_type), locator_properties))
            )
            return True
        except:
            log.error("Exception occurred while waiting for element to be visible.")
            return False

    # Need to test this function
    def wait_for_element_to_be_invisible(self, locator_type, locator_properties):

        """
        This function is used for explicit waits till element displayed
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the boolean value according to the element located or not
        """
        element = (self.get_locator_type(locator_type), locator_properties)
        try:
            WebDriverWait(self.driver, constants.MAX_TIME_OUT).until(
                EC.invisibility_of_element_located(element))
            return True
        except:
            return False

    def is_element_present(self, locator_type, locator_properties):

        """
        This method is used to return the boolean value for element present
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the boolean value according to the element present or not
        """

        flag = False
        try:
            if self.wait_for_element_to_be_present(locator_type, locator_properties):
                flag = True
            else:
                log.error(f"Element not present with locator_properties: {locator_properties} and "
                          f"locator_type: {locator_type}")
        except:
            log.error("Exception occurred during element identification.")
        return flag

    def verify_element_not_present(self, locator_type, locator_properties):

        """
        This method is used to return the boolean value for element present
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the boolean value according to the element present or not
        """

        flag = False
        try:
            if self.wait_for_element_to_be_invisible(locator_type, locator_properties):
                flag = True
            else:
                log.error("Element is visible with locator_properties: " + locator_properties +
                          " and locator_type: " + locator_type)
        except:
            log.error("Exception occurred during element to be invisible.")

        return flag

    def is_element_displayed(self, locator_properties, locator_type):

        """
        This method is used to return the boolean value for element displayed
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the boolean value according to the element displayed or not
        """

        try:
            if self.wait_for_element_to_be_displayed(locator_properties, locator_type):
                return True
            else:
                log.error("Element not found with locator_properties: " + locator_properties +
                          " and locator_type: " + locator_type)
                return False
        except:
            log.error("Exception occurred during element identification.")
            return False

    def is_element_clickable(self, locator_type, locator_properties):

        """
        This method is used to return the boolean value for element clickable
        :param locator_type: it takes locator type as parameter
        :param locator_properties: it takes locator string as parameter
        :return: it returns the boolean value according to the element clickable or not
        """
        self.wait_for_element_to_be_clickable(locator_type, locator_properties)
        element = (self.get_locator_type(locator_type), locator_properties)
        try:
            WebDriverWait(self.driver, constants.EXPLICIT_WAIT).until(
                EC.element_to_be_clickable(element))
            return True
        except:
            log.error("Element is not clickable with locator_properties: " + locator_properties +
                      " and locator_type: " + locator_type)
            return False

    def is_element_checked(self, locator_properties, locator_type, max_time_out=constants.MIN_TIME_OUT):

        """
        This method is used to return the boolean value for element checked/ selected
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :param max_time_out: this is the maximum time to wait for particular element
        :return: it returns the boolean value according to the element present or not
        """

        flag = False
        try:
            if self.is_element_present(locator_properties, locator_type):
                element = self.driver.get_element(locator_properties, locator_type, max_time_out)
                if element.is_selected():
                    flag = True
                else:
                    log.error(
                        "Element is not selected/checked with locator_properties: " +
                        locator_properties + " and locator_type: " + locator_type)
        except:
            flag = False

        return flag

    def verify_elements_located(self, locator_dict):

        """
        This method is used to return the boolean value according to element presents on page
        :param locator_dict: this parameter takes the list of locator value, and it's type
        :return: it returns the boolean value according to element presents on page
        """

        result = []
        try:

            for locator_prop in locator_dict.keys():
                prop_type = locator_dict[locator_prop]
                if self.wait_for_element_to_be_present(prop_type, locator_prop):
                    flag = True
                else:
                    log.error(
                        "Element not found with locator_properties: " + locator_prop +
                        " and locator_type: " + locator_dict[locator_prop])
                    flag = False
                result.append(flag)

        except Exception as ex:
            log.error("Exception occurred during element identification: ", ex)

        if False in result:
            return False
        else:
            return True

    def get_element_list(self, locator_type, locator_properties):

        """
        This method is used to get the element list according to the locator type and property
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the element values as a list
        """

        element = None
        try:
            if self.wait_for_element_to_be_present(locator_type, locator_properties):
                element = self.driver.find_elements(locator_type, locator_properties)
            else:
                log.error("Elements not found with locator_properties: " + locator_properties +
                          " and locator_type: " + locator_type)
        except:
            log.error("Exception occurred during getting elements.")
        return element

    def get_text_from_element(self, locator_type, locator_properties):

        """
        This method is used to get the element's inner text value according to the locator type and property
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the element inner text value
        """
        locator = (self.get_locator_type(locator_type), locator_properties)
        self.is_element_present(locator_type, locator_properties)
        result_text = ""
        try:
            element = WebDriverWait(self.driver, constants.MIN_TIME_OUT).until(
                EC.presence_of_element_located(locator))
            result_text = element.text
            if len(result_text) == 0:
                result_text = element.get_attribute("innerText")
            elif len(result_text) != 0:
                result_text = result_text.strip()
        except:
            log.error("Exception occurred during text retrieval.")
        return result_text

    def get_attribute_value_from_element(self, locator_type, locator_properties, attribute_name):

        """
        This method is used to get the element's attribute value according to the locator type and property
        :param attribute_name: it takes the attribute name as parameter
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns the element attribute value
        """

        attribute_value = ""
        locator = (self.get_locator_type(locator_type), locator_properties)
        try:
            element = WebDriverWait(self.driver, constants.MIN_TIME_OUT).until(
                EC.presence_of_element_located(locator))
            attribute_value = element.get_attribute(attribute_name)
            if attribute_value is None:
                log.error(attribute_name.upper() + " value is empty.")
        except:
            log.error("Exception occurred during attribute value retrieval.")
        return attribute_value

    def mouse_click_action(self, locator_properties, locator_type):

        """
        This method is used to perform mouse click action according to the locator type and property
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns nothing
        """

        try:
            if self.is_element_clickable(locator_properties, locator_type):
                element = self.driver.get_element(locator_properties, locator_type)
                element.click()
            else:
                log.error("Unable to click on the element with locator_properties: "
                          + locator_properties + " and locator_type: " + locator_type)
        except:
            log.error("Exception occurred during mouse click action.")

    def scroll_into_element(self, locator_type, locator_properties):
        """
        This method is used to scroll to invisible element in a dropdown
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns nothing
        """

        try:
            element = WebDriverWait(self.driver, constants.MAX_TIME_OUT).until(
                EC.visibility_of_element_located(
                    (self.get_locator_type(locator_type), locator_properties)))
            actions = ActionChains(self.driver)
            actions.move_to_element(element).perform()
        except:
            log.error("Exception occurred during scrolling to element.")

    def mouse_click_action_on_element_present(self, locator_properties, locator_type="xpath",
                                              max_time_out=constants.MIN_TIME_OUT):
        """
        This method is used to perform mouse click action according to the locator type and property
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :param max_time_out: this is the maximum time to wait for particular element
        :return: it returns nothing
        """

        try:
            if self.is_element_present(locator_properties, locator_type):
                element = self.driver.get_element(locator_properties, locator_type, max_time_out)
                element.click()
            else:
                log.error("Unable to click on the element with locator_properties: "
                          + locator_properties + " and locator_type: " + locator_type)
        except:
            log.error("Exception occurred during mouse click action.")

    def move_to_element_and_click(self, locator_type, locator_properties, max_time_out=constants.MIN_TIME_OUT):

        """
        This method is used when element is not receiving the direct click
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :param max_time_out: this is the maximum time to wait for particular element
        :return: it returns nothing
        """

        try:
            if self.is_element_clickable(self.get_locator_type(locator_type), locator_properties):
                element = self.driver.get_element(self.get_locator_type(locator_type), locator_properties, max_time_out)
                actions = ActionChains(self.driver)
                actions.move_to_element(element).click().perform()
            else:
                log.error("Unable to click on the element with locator_properties: "
                          + locator_properties + " and locator_type: " + locator_type)
        except:
            log.error("Exception occurred during mouse click action.")

    def enter_text_action(self, locator_type, locator_properties, text_value):

        """
        This method is used to enter the value in text input field
        :param locator_type: it takes locator type as parameter
        :param text_value: it takes input string as parameter
        :param locator_properties: it takes locator string as parameter
        :return: it returns nothing
        """
        element = (self.get_locator_type(locator_type), locator_properties)
        self.click_element(locator_type, locator_properties)
        try:
            element = WebDriverWait(self.driver, constants.EXPLICIT_WAIT).until(
                EC.presence_of_element_located(element))
            element.click()
            element.clear()
            element.send_keys(text_value)
        except:
            log.error(f"Unable to send data on the element with locator_properties: {locator_properties}")

    def click_element(self, locator_type, locator_properties):
        self.is_element_present(locator_type, locator_properties)
        element = WebDriverWait(self.driver, constants.EXPLICIT_WAIT).until(
            EC.presence_of_element_located((locator_type, locator_properties)))
        try:
            element.click()
        except ElementClickInterceptedException:
            self.driver.execute_script("arguments[0].click();", element)

    @staticmethod
    def verify_text_contains(actual_text, expected_text):

        """
        This method verifies that actual text in the expected string
        :param actual_text: it takes actual keyword/ substring
        :param expected_text: it takes the string value to search actual keyword in it
        :return: is returns boolean value according to verification
        """

        assert expected_text.lower() in actual_text.lower(), log.error("### TEXT VERIFICATION FAILED:\nActual Text "
                                                                       "--> {}\nExpected Text --> {}"
                                                                       .format(actual_text, expected_text))

    @staticmethod
    def verify_text_match(actual_text, expected_text):

        """
        This method verifies the exact match of actual text and expected text
        :param actual_text: it takes actual string value
        :param expected_text: it takes the expected string value to match with
        :return: it return boolean value according to verification
        """

        if expected_text.lower() == actual_text.lower():
            assert True
        else:
            log.error(f"### TEXT VERIFICATION FAILED:\nActual Text "
                      f"--> {actual_text}\nExpected Text --> {expected_text}")
            assert False, f"### TEXT VERIFICATION FAILED:Actual Text --> {actual_text}Expected Text --> {expected_text}"

    def take_screenshots(self, file_name_initials):

        """
        This method takes screenshot for reporting
        :param file_name_initials: it takes the initials for file name
        :return: it returns the destination directory of screenshot
        """

        file_name = file_name_initials + "." + str(round(time.time() * 1000)) + ".png"
        cur_path = os.path.abspath(os.path.dirname(__file__))
        screenshot_directory = os.path.join(cur_path, r"../Logs/Screenshots/")

        destination_directory = os.path.join(screenshot_directory, file_name)

        try:
            if not os.path.exists(screenshot_directory):
                os.makedirs(screenshot_directory)
            self.driver.save_screenshot(destination_directory)
            log.info("Screenshot saved to directory: " + destination_directory)
        except Exception as ex:
            log.error("### Exception occurred:: ", ex)
            print_stack()

        return destination_directory

    def page_scrolling(self, direction="up"):

        """
        This method is used for page scrolling
        :param direction: it takes the scrolling direction value as parameter
        :return: it returns nothing
        """

        if direction == "up":
            self.driver.execute_script("window.scrollBy(0, -1000);")
        elif direction == "down":
            self.driver.execute_script("window.scrollBy(0, 1000);")

    def switch_to_created_object_frame(self, locator_properties, locator_type="xpath"):

        """
        This method is used for switching to the frame where element is located
        :param locator_properties: it takes locator string as parameter
        :param locator_type: it takes locator type as parameter
        :return: it returns nothing
        """

        try:
            frames = self.get_element_list(locator_type, "//iframe")
            for frame in frames:
                frame_name = frame.get_attribute('name')
                if frame_name is not None:
                    self.driver.switch_to.frame(frame_name)
                    result = self.is_element_present(locator_properties, locator_type)
                    if not result:
                        self.driver.switch_to.default_content()
                        continue

                    else:
                        log.info("Element found on frame: " + str(frame_name))
                        break
                else:
                    self.driver.switch_to.default_content()
                    continue

        except:
            log.error("Element not present on the page.")

    def switch_to_default_content(self):

        """
        This function is used to return to the default frame of the page
        :return: it returns nothing
        """

        try:
            self.driver.switch_to.default_content()
        except:
            log.error("Exception occurred while switching to default content..")

    def press_action_key(self, locator_type, locator_properties):
        element = WebDriverWait(self.driver, 60).until(
            EC.presence_of_element_located((locator_type, locator_properties)))
        element.send_keys(Keys.ENTER)

    @staticmethod
    def string_generator(string_size=8, chars=string.ascii_uppercase + string.digits):
        """
        This function is used to generate random string
        :return: it returns random string
        """
        return ''.join(random.choice(chars) for _ in range(string_size))

    @staticmethod
    def digit_generator(string_size=10, chars=string.digits):
        """
        This function is used to generate random digits
        :return: it returns random digit
        """
        return ''.join(random.choice(chars) for _ in range(string_size))

    def get_assertion_result(self, actual_result, expected_result):
        try:
            self.verify_text_contains(actual_result, expected_result)
            test_result = 'Test passed'
        except AssertionError:
            test_result = 'Test failed'
        return test_result

    @staticmethod
    def log_test_result(test_result):
        for result in test_result:
            log.info(result) if 'Test passed' in result else log.error(result)
        if any('Test failed' in result for result in test_result):
            assert False

    @staticmethod
    def create_random_name():
        name = faker.first_name()
        return name

    @staticmethod
    def create_random_email():
        email = faker.email()
        return email

    @staticmethod
    def create_random_phone_number():
        phone_no = random.randint(10 ** 9, (10 ** 10) - 1)
        return phone_no

   # @staticmethod
    #def start_recording(recording_name):
        ##recorder = pyscreenrec.ScreenRecorder()
        #recorder.start_recording(recording_name, 10)

   # @staticmethod
    #def stop_recording():
        #recorder = pyscreenrec.ScreenRecorder()
        #recorder.stop_recording()

    def action_class_select(self, key_number):
        achains = ActionChains(self.driver)
        if key_number == 1:
            achains.send_keys(Keys.DOWN, Keys.ENTER).perform()
        elif key_number == 2:
            achains.send_keys(Keys.DOWN, Keys.DOWN, Keys.ENTER).perform()
        elif key_number == 3:
            achains.send_keys(Keys.DOWN, Keys.DOWN, Keys.DOWN, Keys.ENTER).perform()
        else:
            print("Number not in range")

    def upload_file(self, locator_type, locator_properties, file_location):
        self.driver.find_element(locator_type, locator_properties).send_keys(file_location)

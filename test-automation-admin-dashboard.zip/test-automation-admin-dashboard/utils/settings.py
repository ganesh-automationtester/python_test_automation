class Credentials:
    USERNAME = "rashi.gupta@zenatix.com"
    PASSWORD = "Zen@1234"
    OTP_MEDIA = 'email'  # Pass here by which media we want to send OTP options are email and phone
    ENVIRONMENT = 'EU-QA'  # If no environment is setup then by default QA environment is selected and value of environment should be DEV/PROD/QA
    BROWSER = 'chrome'


class GetUrl:
    if Credentials().ENVIRONMENT.lower() == 'dev':
        URL = "https://admin-dev.zenatix.com/login"
    elif Credentials().ENVIRONMENT.lower() == 'prod':
        URL = "https://admin.zenatix.com/login"
    elif Credentials().ENVIRONMENT.lower() == 'qa':
        URL = "https://admin-qa.zenatix.com/login"
    elif Credentials().ENVIRONMENT.lower() == 'eu-qa':
        URL = "https://admin-euqa.ecostruxure-building-activate.se.app/login"


import openpyxl
import pandas as pd


def getRowCount(file, sheetName):
    workbook = openpyxl.load_workbook(file)
    sheet = workbook[sheetName]
    return sheet.max_row


def getColumnCount(file, sheetName):
    workbook = openpyxl.load_workbook(file)
    sheet = workbook[sheetName]
    return sheet.max_column


def readData(file, sheetName, rownum, columnno):
    workbook = openpyxl.load_workbook(file)
    sheet = workbook[sheetName]
    return sheet.cell(row=rownum, column=columnno).value


def writeData(file, sheetName, rownum, columnno, data):
    workbook = openpyxl.load_workbook(file)
    sheet = workbook[sheetName]
    sheet.cell(row=rownum, column=columnno).value = data
    workbook.save(file)


def get_list_of_scenario(file, sheetName, columnno):
    workbook = openpyxl.load_workbook(file)
    sheet = workbook[sheetName]
    first_column_values = []
    for row in sheet.iter_rows(min_col=columnno, max_col=columnno):
        for cell in row:
            first_column_values.append(cell.value)
    return first_column_values[1:]

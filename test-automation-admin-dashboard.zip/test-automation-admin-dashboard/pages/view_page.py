import time

from selenium.webdriver.common.by import By

from pages.create_user_page import CreateUserPage
from pages.home_page import HomePage
from pages.login_page import LoginPage
from utils import xlutils
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class ViewUserPage:
    locator_search_field = "//input[@placeholder='Search User']"
    locator_search_button = "//*[@class='anticon user-management-user-search-icon']"
    locator_search_table = "//*[@class='ant-table-container']/div/table/tbody"
    locator_view_button = "//*[text()='View']"
    locator_edit_button = "//*[text()='Edit']"
    locator_head_view = "//*[@class='user-management-home-header-content']"
    locator_first_name = "register-user_first-name"
    locator_middle_name = "register-user_middle-name"
    locator_last_name = "register-user_last-name"
    locator_email = "register-user_email"
    locator_phone_number = "register-user_phone"
    locator_language = "register-user_language"
    locator_notification = "register-user_notification-preference"
    locator_unit = "register-user_unit-type-preference"
    locator_customer = "//*[@class='highlight-label']"
    locator_permission = '(//*[@class="ant-select-selector"])[4]'
    locator_access_tag = '(//*[@class="ant-select-selector"])[2]'
    locator_access_tag_value = '(//*[@class="ant-select-selector"])[3]'
    locator_get_customer_name = "//*[@class='highlight-label']"

    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.login_page = LoginPage(self.driver)
        self.ui_helpers = UIHelpers(self.driver)
        self.home_page = HomePage(self.driver)
        self.create_user = CreateUserPage(self.driver)

    def get_view_page_heading(self):
        self.ui_helpers.wait_for_element_to_be_present("xpath", self.locator_head_view)
        display_message = self.ui_helpers.get_text_from_element("xpath", self.locator_head_view)
        time.sleep(1)
        return display_message

    def field_noneditable(self, locator_type, locator_properties):
        field_tag = self.driver.find_element(locator_type, locator_properties)
        field_value = field_tag.get_attribute('class')
        if self.ui_helpers.verify_text_contains(field_value, 'disable'):
            return True
        else:
            return False

    def get_firstname(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_first_name, 'value')
        time.sleep(1)
        return display_message

    def get_middlename(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_middle_name, 'value')
        return display_message

    def get_lastname(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_last_name, 'value')
        return display_message

    def get_email(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_email, 'value')
        return display_message

    def get_phone_number(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_phone_number, 'value')
        return display_message

    def get_access_tag(self):
        display_message = self.ui_helpers.get_text_from_element('xpath', self.locator_access_tag)
        return display_message

    def get_access_tag_value(self):
        display_message = self.ui_helpers.get_text_from_element('xpath', self.locator_access_tag_value)
        access_tag_values = display_message.split('\n')
        return access_tag_values

    def get_customer_name(self):
        customer_name = self.ui_helpers.get_text_from_element("xpath", self.locator_get_customer_name)
        return customer_name

    def get_application(self):
        application_list = []
        self.ui_helpers.scroll_into_element("xpath", '//*[@class="custom-tree-permisison-application-container"]')
        application = self.driver.find_element("xpath", '//*[@class="custom-tree-permisison-application-container"]')
        application_values = application.find_elements(By.CLASS_NAME, "ant-tree-list-holder-inner")
        for values in application_values:
            main = values.text
            if 'Admin Dashboard' in main:
                application_list = main.split('\n')
                application_list = [item for item in application_list if item != 'Admin Dashboard']
            else:
                application_list = main.split('\n')
        return application_list

    def get_permission_group(self):
        permission_list = []
        permission = self.driver.find_element("xpath", "//*[@class='custom-tree-permission-group-container']")
        permission_values = permission.find_elements(By.CLASS_NAME, 'd-flex')
        for values in permission_values:
            main = values.text
            permission_list.append(main)
        return permission_list

    def get_language_preference(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_language, 'value')
        time.sleep(1)
        return display_message

    def get_notification_preference(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_notification, 'value')
        time.sleep(1)
        return display_message

    def get_unit_preference(self):
        display_message = self.ui_helpers.get_attribute_value_from_element('id', self.locator_unit, 'value')
        time.sleep(1)
        return display_message

    #@staticmethod
    def verify_values(self, expected_list, actual_list):
        self.log.info(expected_list)
        self.log.info(actual_list)
        return set(expected_list) == set(actual_list)

    def verify_user_details(self, entry, sheet_name):
        test_data = './test_data/User Management Test Data.xlsx'
        self.log.info('Fetching basic details')
        first_name = xlutils.readData(test_data, sheet_name, 1 + entry, 1)
        middle_name = xlutils.readData(test_data, sheet_name, 1 + entry, 2)
        last_name = xlutils.readData(test_data, sheet_name, 1 + entry, 3)
        email = xlutils.readData(test_data, sheet_name, 1 + entry, 4)
        phone_number = xlutils.readData(test_data, sheet_name, 1 + entry, 6)
        name_of_customer = xlutils.readData(test_data, sheet_name, 1 + entry, 7)
        access_tag_name = xlutils.readData(test_data, sheet_name, 1 + entry, 8)
        access_tag_value_name = xlutils.readData(test_data, sheet_name, 1 + entry, 9)
        application_name = xlutils.readData(test_data, sheet_name, 1 + entry, 10)
        permission_name = xlutils.readData(test_data, sheet_name, 1 + entry, 11)
        language_name = xlutils.readData(test_data, sheet_name, 1 + entry, 12)
        notification_name = xlutils.readData(test_data, sheet_name, 1 + entry, 13)
        unit_name = xlutils.readData(test_data, sheet_name, 1 + entry, 14)
        self.log.info(email)
        self.home_page.search_user_by_username(email)
        self.home_page.click_search_button()
        self.home_page.click_menu()
        
        self.ui_helpers.verify_text_match(self.get_firstname(), first_name.strip())
        self.log.info(first_name)
        if middle_name is not None:
            self.ui_helpers.verify_text_match(self.get_middlename(), middle_name.strip())
        self.log.info(middle_name)
        self.ui_helpers.verify_text_match(self.get_lastname(), last_name.strip())
        self.log.info(last_name)
        self.ui_helpers.verify_text_match(self.get_email(), email.strip())
        if phone_number is not None:
            self.ui_helpers.verify_text_match(self.get_phone_number(), str(phone_number).strip())
        self.log.info(phone_number)
        self.ui_helpers.verify_text_match(self.get_customer_name(), name_of_customer.strip())
        self.log.info(name_of_customer)
        self.ui_helpers.verify_text_match(self.get_access_tag(), access_tag_name.strip())
        if ',' in access_tag_value_name:
            value_loop = access_tag_value_name.split(',')
            assert self.verify_values(self.get_access_tag_value(), value_loop)
        else:
            assert self.verify_values(self.get_access_tag_value(), [access_tag_value_name])
        if application_name is not None:
            if ',' in application_name:
                application_loop = application_name.split(',')
                permission_loop = permission_name.split(',')
                self.log.info(self.get_permission_group())
                self.log.info(application_loop)
                self.log.info(permission_loop)
                assert self.verify_values(self.get_application(), application_loop)
                assert self.verify_values(self.get_permission_group(), permission_loop)
            else:
                assert self.verify_values(self.get_application(), [application_name.strip()])
                assert self.verify_values(self.get_permission_group(), [permission_name.strip()])
        if language_name is not None:
            self.ui_helpers.verify_text_match(self.get_language_preference(), language_name.strip())
        else:
            self.ui_helpers.verify_text_match(self.get_language_preference(), 'english')
        if notification_name is not None:
            self.ui_helpers.verify_text_match(self.get_notification_preference(), notification_name.strip())
        else:
            self.ui_helpers.verify_text_match(self.get_notification_preference(), 'email')
        if unit_name is not None:
            self.ui_helpers.verify_text_match(self.get_unit_preference(), unit_name.strip())
        else:
            self.ui_helpers.verify_text_match(self.get_unit_preference(), 'metric')
        self.log.info('User details verified')

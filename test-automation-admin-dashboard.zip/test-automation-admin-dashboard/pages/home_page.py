import time

from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class HomePage:
    # List of locators for home page
    locator_search_user_input_box = "//input[@placeholder='Search User']"
    locator_search_button = "//*[@class='anticon user-management-user-search-icon']"
    locator_click_profile = "//div[@class='brand-header-login-info']"
    locator_click_logout = "//div[text()='Logout']"
    locator_click_enable = "//*[text()='Enable']"
    locator_click_bulk_edit = "//*[text()='Bulk Edit']"
    locator_click_disable = "//*[text()='Disable']"
    locator_click_dropdown = "//*[@class='ant-dropdown-trigger filter-select']"
    locator_dropdown_search_box = "//input[@placeholder='Search']"
    locator_click_apply_filter = "//*[text()='Apply Filter']"
    locator_select_user = "//tbody/tr[1]/td[1]"
    locator_select_all_users = "//thead/tr/th[1]"
    locator_get_selected_username = "//tbody//tr[1]//td[2]"
    locator_get_status_of_selected_user = "//tbody/tr[1]/td[3]"
    locator_accept_confirmation_prompt = "//*[text()='Yes']"
    locator_click_reset_filter_button = "//*[text()='Reset']"
    locator_click_add_user = "//*[text()=' Add User']"
    locator_click_alarm_management = "(//*[@class='dashboard-items']//li)[2]"
    locator_get_no_permission_display_msg = "//div[@class='no-permission-msg']"
    locator_click_hide_side_pane = "//span[@aria-label='left']"
    locator_click_open_side_pane = "//span[@aria-label='right']"
    locator_logo_name = "//div[@class='brand-header-logo-info']"
    locator_logo = "//img[@alt='ZenatixLogo']"
    locator_click_view_button = "//span[normalize-space()='View']"
    locator_click_edit_button = "//*[text()='Edit']"
    locator_click_menu_button = "//*[@class='ant-table-tbody']/tr"
    locator_get_header_value_username = "//thead//tr//th[2]"
    locator_get_header_value_status = "//thead//tr//th[3]"
    locator_side_pane_hidden = "//ul[contains(@class, 'ant-menu-inline-collapsed')]"
    locator_list_dropdown = "//*[@class='user-management-home-content-filters']//a"
    locator_home_screen_display_msg = "//*[@class='user-management-home-content']"
    locator_home_screen_display_msg_no_access = "//*[@class='user-management-container']"
    locator_loader = "//*[@class='ui active transition visible dimmer']"
    locator_reset_button_disabled = "//*[@class='reset-filter-action disable-reset-btn']"

    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)

    def search_user_by_username(self, username):
        self.ui_helpers.enter_text_action("xpath", self.locator_search_user_input_box, username)
        time.sleep(1)

    def click_search_button(self):
        self.ui_helpers.click_element("xpath", self.locator_search_button)
        time.sleep(1)

    def click_logout(self):
        self.ui_helpers.click_element("xpath", self.locator_click_profile)
        self.ui_helpers.click_element("xpath", self.locator_click_logout)
        self.log.info('Logging out...')
        time.sleep(1)

    def click_enable(self):
        self.ui_helpers.click_element("xpath", self.locator_click_enable)
        time.sleep(1)

    def click_disable(self):
        self.ui_helpers.click_element("xpath", self.locator_click_disable)
        time.sleep(1)

    def click_bulk_edit(self):
        self.ui_helpers.click_element("xpath", self.locator_click_bulk_edit)
        time.sleep(1)

    def select_options_from_dropdown_by_value(self, filter_name, value):
        if filter_name.lower() == 'customer':
            self.ui_helpers.click_element("xpath", f"({self.locator_click_dropdown})[1]")
            self.ui_helpers.enter_text_action("xpath", f"({self.locator_dropdown_search_box})[1]", value)
            self.ui_helpers.click_element("xpath", "(//*[@class='filter-select-dropdown'])[1]//ul//li")
        elif filter_name.lower() == 'site':
            self.ui_helpers.click_element("xpath", f"({self.locator_click_dropdown})[1]")
            self.ui_helpers.enter_text_action("xpath", f"({self.locator_dropdown_search_box})[2]", value)
            self.ui_helpers.click_element("xpath", "(//*[@class='filter-select-dropdown'])[2]//ul//li[2]")
        elif filter_name.lower() == 'status':
            self.ui_helpers.click_element("xpath", f"({self.locator_click_dropdown})[2]")
            self.ui_helpers.enter_text_action("xpath", f"({self.locator_dropdown_search_box})[3]", value)
            self.ui_helpers.click_element("xpath", "(//*[@class='filter-select-dropdown'])[3]//ul//li[2]")
        elif filter_name.lower() == 'permission group':
            self.ui_helpers.click_element("xpath", f"({self.locator_click_dropdown})[3]")
            self.ui_helpers.enter_text_action("xpath", f"({self.locator_dropdown_search_box})[4]", value)
            self.ui_helpers.click_element("xpath", "(//*[@class='filter-select-dropdown'])[4]//ul//li[2]")
        elif filter_name.lower() == 'application':
            self.ui_helpers.click_element("xpath", f"({self.locator_click_dropdown})[4]")
            self.ui_helpers.enter_text_action("xpath", f"({self.locator_dropdown_search_box})[5]", value)
            self.ui_helpers.click_element("xpath", "(//*[@class='filter-select-dropdown'])[5]//ul//li[2]")
        time.sleep(1)

    def click_apply_filter(self):
        self.ui_helpers.click_element("xpath", self.locator_click_apply_filter)
        time.sleep(1)

    def select_user(self):
        self.ui_helpers.click_element("xpath", self.locator_select_user)
        time.sleep(1)

    def select_all_users(self):
        self.ui_helpers.click_element("xpath", self.locator_select_all_users)
        time.sleep(1)

    def get_username(self):
        username = self.ui_helpers.get_text_from_element("xpath", self.locator_get_selected_username)
        time.sleep(1)
        return username

    def get_status_of_selected_user(self):
        status = self.ui_helpers.get_text_from_element("xpath", self.locator_get_status_of_selected_user)
        time.sleep(1)
        return status

    def accept_confirmation_prompt(self):
        self.ui_helpers.click_element("xpath", self.locator_accept_confirmation_prompt)
        time.sleep(1)

    def click_reset_button(self):
        self.ui_helpers.click_element("xpath", self.locator_click_reset_filter_button)
        time.sleep(1)

    def click_add_user(self):
        self.ui_helpers.click_element("xpath", self.locator_click_add_user)
        time.sleep(1)

    def click_alarm_management_page(self):
        self.ui_helpers.click_element("xpath", self.locator_click_alarm_management)
        time.sleep(1)

    def get_no_permission_display_msg(self):
        display_msg = self.ui_helpers.get_text_from_element("xpath", self.locator_get_no_permission_display_msg)
        time.sleep(1)
        return display_msg

    def click_hide_side_pane(self):
        self.ui_helpers.click_element("xpath", self.locator_click_hide_side_pane)
        time.sleep(1)

    def click_open_side_pane(self):
        self.ui_helpers.click_element("xpath", self.locator_click_open_side_pane)
        time.sleep(1)

    def click_view_user_details_button(self):
        self.ui_helpers.click_element("xpath", self.locator_click_view_button)
        time.sleep(1)

    def click_edit_user_details_button(self):
        self.ui_helpers.click_element("xpath", self.locator_click_edit_button)
        time.sleep(1)

    def click_menu(self):
        self.ui_helpers.click_element("xpath", self.locator_click_menu_button)
        time.sleep(1)

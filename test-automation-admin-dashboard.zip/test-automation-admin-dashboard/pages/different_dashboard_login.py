import time
from pages.login_page import LoginPage
from selenium.webdriver.common.by import By # type: ignore
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class Login_Scenario_Page:
    # write locators here
    locator_username = ''
    locator_password = ''
    locator_login_btn = ''
    locator_click_send_button =''
    locator_alarmsmanagement =''
    
    
    
    
    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)
        self.dp = LoginPage(self.driver)

    def cma_setUsername(self, username):
        self.ui_helpers.enter_text_action('id', self.locator_username, username)

    def cma_setPassword(self, password):
        self.ui_helpers.enter_text_action('id', self.locator_password, password)

    def click_next(self):
        self.ui_helpers.click_element('xpath', self.locator_login_btn)

    def pp_setUsername(self, username):
        self.ui_helpers.enter_text_action('id', "basic_username", username)

    def pp_setPassword(self, password):
        self.ui_helpers.enter_text_action('id', "basic_password", password)

    def check_customer_schedules_dashboard_login(self, dashboard, user_type, username, password):
        if dashboard.lower() == 'customer dashboard':
                url = "https://dashboard-qa.zenatix.com/"
        else:
                url = "https://schedules-dev-qa.zenatix.com/"
        self.driver.get(url)
        self.dp.setUserName(username)
        self.dp.setPassword(password)
        self.dp.clickLogin()
        if self.ui_helpers.is_element_present('xpath', self.locator_click_send_button):
            self.dp.click_send_otp()
            time.sleep(1)
            otp = self.dp.generate_otp(username, password)
            time.sleep(2)
            self.dp.enter_otp(otp)
            self.dp.click_submit()
        if user_type == 'No App Access':
            if dashboard.lower() == 'customer dashboard':
                if self.ui_helpers.is_element_present('xpath', "//*[@class='no-permission-msg']"):
                    display_msg = self.ui_helpers.get_text_from_element('xpath', "//*[@class='no-permission-msg']")
                    self.log.info(f'User is getting display msg as {display_msg} for {dashboard}')
                elif self.ui_helpers.is_element_present('xpath', "//*[@class='dashboard-items']//div[1]"):
                    self.log.info(f'{user_type} is able to login to {dashboard}')
                else:
                    self.log.info(f'Login failed for {dashboard} with {user_type}')
            else:
                if self.ui_helpers.is_element_present('xpath', "//*[@class='permission-msg']"):
                    display_msg = self.ui_helpers.get_text_from_element('xpath', "//*[@class='permission-msg']")
                    self.log.info(f'User is getting display msg as {display_msg}')
                elif self.ui_helpers.is_element_present('xpath', "//*[@class='dashboard-items']//div[1]"):
                    self.log.info(f'{user_type} is able to login to {dashboard}')
                else:
                    self.log.info(f'Login failed for {dashboard} with {user_type}')
        else:
            if self.ui_helpers.is_element_present('xpath', "//*[@class='dashboard-items']//div[1]"):
                self.log.info(f'Login successful for {dashboard} with {user_type}')
            elif self.demo_v2.get_toast_message() == 'Invalid OTP':
                self.log.info('Invalid OTP, Retrying....')
                time.sleep(60)
                self.dp.click_send_otp()
                time.sleep(1)
                otp = self.dp.generate_otp(username, password)
                time.sleep(2)
                self.dp.enter_otp(otp)
                self.dp.click_submit()
                if self.ui_helpers.is_element_present('xpath', "//*[@class='dashboard-items']//div[1]"):
                    self.log.info(f'Login successful for {dashboard} with {user_type}')
            else:
                self.log.info(f'Login failed for {dashboard} with {user_type}')
        self.driver.delete_all_cookies()
        self.driver.refresh()
        time.sleep(3)

    def check_cma_login(self, user_type, username, password):
        url = "https://clientapp-qa.zenatix.com/"
        self.driver.get(url)
        if user_type == 'Old User':
            self.cma_setUsername(username)
            self.cma_setPassword(password)
            self.dp.clickLogin()
        else:
            self.cma_setUsername(username)
            self.cma_setPassword(password)
            self.dp.clickLogin()
            if self.ui_helpers.is_element_present('xpath', self.locator_click_send_button):
                self.dp.click_send_otp()
                time.sleep(1)
                otp = self.dp.generate_otp(username, password)
                time.sleep(2)
                self.dp.enter_otp(otp)
                self.click_next()
        if user_type == 'No App Access':
            if (self.ui_helpers.is_element_present('xpath', "//*[@href='/home/Tickets']") or
                    self.ui_helpers.is_element_present('xpath', "//*[@href='/home/Controls']")):
                self.log.info(f'{user_type} User is able to login to CMA')
            elif self.ui_helpers.is_element_present('xpath', self.locator_click_send_button):
                self.log.info(f'Login failed for CMA with {user_type}')
        else:
            if self.ui_helpers.is_element_present('xpath', "//*[@href='/home/Profile']"):
                self.log.info(f'Login successful for CMA with {user_type}')
            elif self.demo_v2.get_toast_message() == 'Invalid OTP':
                self.log.info('Invalid OTP, Retrying....')
                time.sleep(60)
                self.dp.click_send_otp()
                time.sleep(1)
                otp = self.dp.generate_otp(username, password)
                time.sleep(2)
                self.dp.enter_otp(otp)
                self.click_next()
                if self.ui_helpers.is_element_present('xpath', "//*[@href='/home/Profile']"):
                    self.log.info(f'Login successful for CMA with {user_type}')
            else:
                self.log.info(f'Login failed for CMA with {user_type}')
        self.driver.delete_all_cookies()
        self.driver.refresh()
        time.sleep(3)

    def check_login_makersuite(self, user_type, username, password):
        url = "https://makersuite-qa.zenatix.com/"
        self.driver.get(url)
        self.dp.setUsername(username)
        self.dp.setPassword(password)
        self.dp.clickLogin()
        if (user_type != 'No App Access' and
                self.ui_helpers.is_element_present('xpath', self.locator_click_send_button)):
            self.dp.click_send_otp()
            time.sleep(1)
            otp = self.dp.generate_otp(username, password)
            time.sleep(2)
            self.dp.enter_otp(otp)
            self.dp.click_submit()
        if user_type == 'No App Access':
            if self.ui_helpers.is_element_present('name', self.locator_username):
                error_msg = self.ui_helpers.get_text_from_element('id', "error-msg")
                self.log.info(f'{user_type} User is getting error msg:{error_msg}')
            elif self.ui_helpers.is_element_present('xpath', self.locator_click_send_button):
                self.log.info(f'{user_type} User is able to login to Makersuite')
            else:
                self.log.info(f'Login failed for Makersuite with {user_type}')
        else:
            if self.ui_helpers.is_element_present('xpath', "//*[@href='/makerSuite/']"):
                self.log.info(f'Login successful for Makersuite with {user_type}')
            elif self.demo_v2.get_toast_message() == 'Invalid OTP':
                self.log.info('Invalid OTP, Retrying....')
                time.sleep(60)
                self.dp.click_send_otp()
                time.sleep(1)
                otp = self.dp.generate_otp(username, password)
                time.sleep(2)
                self.dp.enter_otp(otp)
                self.dp.click_submit()
                if self.ui_helpers.is_element_present('xpath', "//*[@href='/makerSuite/']"):
                    self.log.info(f'Login successful for Makersuite with {user_type}')
            else:
                self.log.info(f'Login failed for Makersuite with {user_type}')
        self.driver.delete_all_cookies()
        self.driver.refresh()
        time.sleep(3)

    def check_login_partner_portal(self, user_type, username, password):
        url = "https://device-dev-qa.zenatix.com/"
        self.driver.get(url)
        self.pp_setUsername(username)
        self.pp_setPassword(password)
        self.dp.clickLogin()
        time.sleep(1)
        if self.ui_helpers.is_element_present('xpath', "//*[text()='Yes']"):
            self.ui_helpers.click_element('xpath', "//*[text()='Yes']")
        if (user_type != 'No App Access' and
                self.ui_helpers.is_element_present('xpath', self.locator_click_send_button)):
            self.dp.click_send_otp()
            time.sleep(1)
            otp = self.dp.generate_otp(username, password)
            time.sleep(2)
            self.dp.enter_otp(otp)
            self.dp.click_submit()
        time.sleep(1)
        self.driver.refresh()
        time.sleep(3)
        if user_type == 'No App Access':
            locator = self.ui_helpers.is_element_present('id', "basic_username")
            if locator:
                error_msg = self.ui_helpers.get_text_from_element('xpath', "(//*[@id='basic']//span)[1]")
                self.log.info(f'{user_type} User is getting error msg:{error_msg}')
            elif self.ui_helpers.is_element_present('xpath', self.locator_click_send_button):
                self.log.info(f'{user_type} User is able to login to Partner Portal')
            else:
                self.log.info(f'Login failed for Partner Portal with {user_type}')
        else:
            if self.ui_helpers.is_element_present('xpath', "//ul"):
                self.log.info(f'Login successful for Partner Portal with {user_type}')
                time.sleep(2)
                self.ui_helpers.click_element('xpath', "//*[@data-icon='poweroff']")
            elif self.demo_v2.get_toast_message() == 'Invalid OTP':
                self.log.info('Invalid OTP, Retrying....')
                time.sleep(60)
                self.dp.click_send_otp()
                time.sleep(1)
                otp = self.dp.generate_otp(username, password)
                time.sleep(2)
                self.dp.enter_otp(otp)
                self.dp.click_submit()
                if self.ui_helpers.is_element_present('xpath', "//ul"):
                    self.log.info(f'Login successful for Partner Portal with {user_type}')
                    time.sleep(2)
                    self.ui_helpers.click_element('xpath', "//*[@data-icon='poweroff']")
            else:
                self.log.info(f'Login failed for Partner Portal with {user_type}')
        self.driver.delete_all_cookies()
        self.driver.refresh()
        time.sleep(3)

    def check_login_admin_dashboard(self, user_type, username, password):
        url = "https://admin-qa.zenatix.com/"
        self.driver.get(url)
        self.dp.setUsername(username)
        self.dp.setPassword(password)
        self.dp.clickLogin()
        if self.ui_helpers.is_element_present('xpath', self.locator_click_send_button):
            self.dp.click_send_otp()
            time.sleep(1)
            otp = self.dp.generate_otp(username, password)
            time.sleep(2)
            self.dp.enter_otp(otp)
            self.dp.click_submit()
        if user_type == 'No App Access' or user_type == 'Old User':
            time.sleep(2)
            pages = self.driver.find_elements(By.XPATH, "//ul//li")
            for page in range(len(pages)):
                if page == 1:
                    self.ui_helpers.click_element("xpath", self.locator_alarmsmanagement)
                time.sleep(3)
                if self.ui_helpers.is_element_present('xpath', "//*[@class='no-permission-msg']"):
                    error_msg = self.ui_helpers.get_text_from_element('xpath', "//*[@class='no-permission-msg']")
                    self.log.info(f'{user_type} User is getting error msg:{error_msg}')
                elif self.ui_helpers.is_element_present('xpath', "//*[contains(@placeholder, 'Search')]"):
                    self.log.error(f'{user_type} User is able to login to Admin Dashboard')
                else:
                    self.log.info(f'Login failed for Admin Dashboard with {user_type}')
        elif user_type == 'New User' or user_type == 'Staff User':
            time.sleep(2)
            pages = self.driver.find_elements(By.XPATH, "//ul//li")
            for page in range(len(pages)):
                if page == 1:
                    self.ui_helpers.click_element("xpath", self.locator_alarmsmanagement)
                time.sleep(3)
                if self.ui_helpers.is_element_present('xpath', "//*[contains(@placeholder, 'Search')]"):
                    self.log.info(f'Login successful for Admin Dashboard with {user_type}')
                else:
                    self.log.info(f'Login failed for Admin Dashboard with {user_type}')
        self.driver.delete_all_cookies()
        self.driver.refresh()
        time.sleep(3)

   
import time
from selenium.webdriver import ActionChains, Keys # type: ignore
from selenium.webdriver.common.by import By # type: ignore
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers
import constants


class ResetPasswordPage:
    #write locators here
    locator_username = 'reset-password-form_username'
    locator_password = 'reset-password-form_newPassword'
    locator_re_password = 'reset-password-form_confirmNewPassword'
    locator_read_privacy_policy = ''
    locator_agree_btn = ''
    locator_next_btn = '//*[text()="Next"]'
    locator_clear_btn = '//*[text()="Clear"]'
    locator_reset_password_btn = '//*[@class="forgot-password-trigger"]'
    locator_reset_password_heading = '//*[text()="Generate/Change Password"]'
    locator_send_otp_btn = '//*[text()="Send OTP"]'
    
    
    
    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)
        
    def setnewpassword(self,url, username, password):
        self.driver.geturl(url)
        self.ui_helpers.enter_text_action("id", self.locator_username, username)
        self.ui_helpers.enter_text_action("id", self.locator_password, password)
        self.ui_helpers.enter_text_action("id", self.locator_re_enter_password, password)
        self.ui_helpers.click_element("id", self.locator_read_privacy_policy)
        self.ui_helpers.click_element("xpath", self.locator_agree_btn)
        self.ui_helpers.click_element("id", self.locator_next_btn)
        
        
    def click_reset_password_btn(self):
        self.ui_helpers.click_element('xpath', self.locator_reset_password_btn)
        time.sleep(3)
        
    def get_reset_password_heading(self):
        display_msg = self.ui_helpers.get_text_from_element('xpath', self.locator_reset_password_heading)
        time.sleep(1)
        return display_msg
    
    def enter_username(self, username):
        self.ui_helpers.enter_text_action("id", self.locator_username, username)
        time.sleep(1)
    
    def enter_password(self, password):
        self.ui_helpers.enter_text_action('id', self.locator_password, password)
        time.sleep(1)
        
    def re_enter_password(self, password):
        self.ui_helpers.enter_text_action('id', self.locator_re_password, password)
        time.sleep(1)
        
    def click_next_btn(self):
        self.ui_helpers.click_element('xpath', self.locator_next_btn)
        time.sleep(1)
        
    def click_send_otp_btn(self):
        self.ui_helpers.click_element('xpath', self.locator_send_otp_btn)
        time.sleep(1)

        
    
            
    
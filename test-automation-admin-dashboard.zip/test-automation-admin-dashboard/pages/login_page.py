import datetime
import time

from selenium.webdriver.common.by import By

import constants
from pages.home_page import HomePage
from utils.settings import Credentials
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class LoginPage:
    # List of locators for login page
    locator_username = "//input[@placeholder='Username']"
    locator_password = "//input[@placeholder='Password']"
    locator_username = "username"
    locator_password = "password"
    locator_sign_in_button = "//*[text()='Sign In']"
    locator_otp_send_button = (By.XPATH, "//button[text()='Send']")
    locator_validate_otp = (By.XPATH, "//button[text()='Next']")
    locator_otp_input_box = (By.NAME, "OTP")
    locator_click_otp_media = (By.XPATH, "//span[@title='Email']")
    locator_otp_media_phone = (By.XPATH, "//div[@title='Phone']")
    locator_otp_media_email = (By.XPATH, "//div[@title='Email']")
    locator_toast_message = "(//div[@role='alert'])[1]"
    locator_display_message = "error-msg"
    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)
        self.hp = HomePage(self.driver)

    def setUserName(self, username):
        # This function enter the username in username field
        self.ui_helpers.enter_text_action("name", self.locator_username, username)
        time.sleep(1)

    def setPassword(self, password):
        self.ui_helpers.enter_text_action("name", self.locator_password, password)
        time.sleep(1)

    def clickLogin(self):
        self.ui_helpers.click_element("xpath", self.locator_sign_in_button)
        time.sleep(1)

   
    def getToastMessage(self):
        toast_message = self.ui_helpers.get_text_from_element("xpath", self.locator_toast_message)
        time.sleep(1)
        return toast_message

    def getErrorDisplayMessage(self):
        display_message = self.ui_helpers.get_text_from_element("id", self.locator_display_message)
        time.sleep(1)
        return display_message
    
    def login_to_dashboard(self, username=Credentials.USERNAME, password=Credentials.PASSWORD):
        self.setUserName(username)
        self.setPassword(password)
        self.clickLogin()
        actual_text = self.ui_helpers.get_text_from_element("xpath", self.hp.locator_home_screen_display_msg)
        expected_text = constants.DISPLAY_MSG_HOME_PAGE_UM
        self.ui_helpers.verify_text_contains(actual_text, expected_text)
        time.sleep(1)
        self.log.info('Successfully logged in to dashboard')
    
    
    

    def login_to_dashboard_part(self, username=Credentials.USERNAME, password=Credentials.PASSWORD):
        self.setUserName(username)
        self.setPassword(password)
        self.clickLogin()
        if self.ui_helpers.is_element_present('xpath', "//span[@title='Email']"):
            self.click_send_otp()
            time.sleep(1)
            otp = self.generate_otp(username, password)
            time.sleep(2)
            self.enter_otp(otp)
            self.click_submit()
            for otp_retry in range(1, 4):
                if self.ui_helpers.is_element_present('xpath', "//*[@class='dashboard-items']//div[1]"):
                    self.log.info('Login successful')
                    break
                else:
                    self.log.error(f'OTP Verification Failed, Retrying....{otp_retry}')
                    time.sleep(62)
                    self.click_send_otp()
                    time.sleep(1)
                    latest_otp = self.generate_otp(username, password)
                    time.sleep(2)
                    self.enter_otp(latest_otp)
                    self.click_submit()
            #break
        else:
            self.log.error(f'Login failed, Retrying....{1}')
            self.driver.delete_all_cookies()
            self.driver.refresh()
        actual_text = self.ui_helpers.get_text_from_element("xpath", self.hp.locator_home_screen_display_msg)
        expected_text = constants.DISPLAY_MSG_HOME_PAGE_UM
        self.ui_helpers.verify_text_contains(actual_text, expected_text)
        time.sleep(1)
        self.log.info('Successfully logged in to dashboard')
        
        
    def click_send_otp(self):
        self.ui_helpers.click_element('xpath', locator_click_send_button)
        
    def enter_otp(self, otp):
        try:
            element = WebDriverWait(self.driver, 60).until(
                EC.presence_of_element_located((By.NAME, locators.xpath_enter_otp)))
            element.clear()
            time.sleep(1)
            element.send_keys(otp)
        except Exception as e:
            self.log.error(f"Web element not found {e}")
    
    def generate_otp(self, email, password):
        key = base64.b32encode(Pages.returnValue(email).encode())
        TOTP = pyotp.TOTP(key)
        otp = TOTP.at(for_time=int(self.return_otp_creation_time(email, password)), counter_offset=0)
        return otp
    
    def click_submit(self):
        self.ui_helpers.click_element('xpath', locator_click_submit_button)
        
        
        
    @staticmethod
    def returnValue(email):
        return str(email) + constants.secret_key

    def return_otp_creation_time(self, email, password):
        url = "http://wattman-qa.zenatix.com/graphql/"
        query = f"""
    query Zenatixuser {{
        zenatixuser(username: "{email}", password: "{password}") {{
            id
            otpCreationTime
        }}
    }}
    """

        headers = {
            "Content-Type": "application/json"
        }

        payload = {
            "query": query
        }

        response = requests.post(url, json=payload, headers=headers)

        data = response.json()
        otp_creation_time_str = data['data']['zenatixuser']['otpCreationTime']
        otp_creation_time = datetime.fromisoformat(otp_creation_time_str.replace('Z', '+00:00')).timestamp()
        return otp_creation_time

    
   


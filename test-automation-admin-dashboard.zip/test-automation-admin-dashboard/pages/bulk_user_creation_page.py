import os
import time

from selenium.webdriver.common.by import By

from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class BulkCreateUser:
    locator_bulk_create_button = "//*[text()='Bulk Create']"
    locator_download_template = "//*[text()='Click here']"
    locator_upload_button = "//*[text()='Upload']"
    locator_next_button = "//*[text()='Next']"
    locator_upload_file = "//input[@type='file']"

    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)

    def click_bulk_create_button(self):
        self.ui_helpers.click_element("xpath", self.locator_bulk_create_button)
        time.sleep(1)

    def click_download_template(self):
        self.ui_helpers.click_element("xpath", self.locator_download_template)
        time.sleep(1)

    def check_upload_button_clickable(self):
        self.ui_helpers.is_element_clickable("xpath", self.locator_upload_button)
        time.sleep(1)

    def upload_file(self, file_location):
        self.ui_helpers.upload_file("xpath", self.locator_upload_file, os.path.abspath(file_location))
        time.sleep(1)

    def click_next_button(self):
        self.ui_helpers.click_element("xpath", self.locator_next_button)
        time.sleep(1)
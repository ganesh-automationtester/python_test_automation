import time

import constants
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class BulkEditUser:
    # Write locators here
    locator_save_button = "//*[text()='Save']"
    locator_click_dropdown = "//div[@class='custom-tree-permission-container']//div[@class='d-flex']"
    locator_confirmation_prompt_msg = "//*[@class='ant-modal-body']"
    locator_select_permission_group = "//*[@class='rc-virtual-list-holder-inner']"
    locator_enter_access_tag = "(//input[@type='search'])[1]"
    locator_enter_access_tag_value = "(//input[@type='search'])[2]"
    locator_select_access_tag_value = "(//*[@class='rc-virtual-list-holder-inner'])[2]"
    locator_select_access_tag = "(//*[@class='rc-virtual-list-holder-inner'])[1]"
    locator_cancel_button = "//*[text()='Cancel']"
    locator_main_headers = "//div[@class='user-form-main-heading color-black']"
    locator_select_customer = "//div[@class='customer-alpha-checkbox']//label//span"
    locator_add_to_existing_btn = '//*[@value="add-to-existing"]'
    locator_replace_all_with_btn = '//*[@value="replace-all-with"]'
    locator_add_to_existing_btn_2 = '(//*[@value="add-to-existing"])[2]'
    locator_replace_all_with_btn_2 = '(//*[@value="replace-all-with"])[2]'
    locator_clear_application_permission_btn = '//*[@value="clear-all"]'
    locator_search_customer_input_box = "//input[@placeholder='Search']"
    locator_customer_field_name = "//div[@class='customer-container']"
    locator_site_field_name = "//div[@class='site-container']"
    locator_site_field_sub_header_names = "//div[@class='site-container-subheading']"
    locator_application_names = "//div[@class='ant-tree-list-holder']//span[@title]"
    locator_application_and_permission_group_header_name = "//*[@class='custom-tree-permission-heading']"
    locator_select_application = "//span[@class='ant-tree-checkbox-inner']"
    locator_permission_groups = "//*[@class='rc-virtual-list-holder-inner']//div[@title]"
    locator_get_info_msg = "//*[@class='bulk-edit-content']"
    locator_yes_button = "//*[text()='Yes']"
    locator_no_button = "//*[text()='No']"

    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)

    def get_main_header_names(self):
        field_names = []
        fields = self.ui_helpers.get_element_list("xpath", self.locator_main_headers)
        for field in range(1, len(fields) + 1):
            field_name = self.ui_helpers.get_text_from_element("xpath",
                                                               f'({self.locator_main_headers})[{field}]')
            field_names.append(field_name)
        time.sleep(1)
        return field_names

    def get_customer_field_name(self):
        field_name = self.ui_helpers.get_text_from_element("xpath", self.locator_customer_field_name)
        time.sleep(1)
        return field_name

    def get_site_field_name(self):
        field_name = self.ui_helpers.get_text_from_element("xpath", self.locator_site_field_name)
        time.sleep(1)
        return field_name

    def get_sites_sub_header_names(self):
        field_names = []
        fields = self.ui_helpers.get_element_list("xpath", self.locator_site_field_sub_header_names)
        for field in range(1, len(fields) + 1):
            field_name = self.ui_helpers.get_text_from_element("xpath",
                                                               f'({self.locator_site_field_sub_header_names})[{field}]')
            field_names.append(field_name)
        time.sleep(1)
        return field_names

    def get_application_names(self):
        field_names = []
        fields = self.ui_helpers.get_element_list("xpath", self.locator_application_names)
        for field in range(1, len(fields) + 1):
            locator_property = f'({self.locator_application_names})[{field}]'
            field_name = self.ui_helpers.get_attribute_value_from_element("xpath", locator_property, 'title')
            field_names.append(field_name)
        time.sleep(1)
        return field_names

    def get_permission_group_names(self):
        self.ui_helpers.click_element("xpath", f"//*[@title='{constants.ALARM_MANAGEMENT}']")
        self.ui_helpers.click_element("xpath", f'({self.locator_click_dropdown})[1]')
        field_names = []
        for field in range(1, 4):
            locator_property = f'({self.locator_permission_groups})[{field}]'
            field_name = self.ui_helpers.get_attribute_value_from_element("xpath", locator_property, 'title')
            field_names.append(field_name)
        time.sleep(1)
        return field_names

    def get_application_and_permission_group_header_names(self):
        field_names = []
        fields = self.ui_helpers.get_element_list("xpath", self.locator_application_and_permission_group_header_name)
        for field in range(1, len(fields) + 1):
            locator_property = f'({self.locator_application_and_permission_group_header_name})[{field}]'
            field_name = self.ui_helpers.get_text_from_element("xpath", locator_property)
            field_names.append(field_name)
        time.sleep(1)
        return field_names
    
    def select_type_of_customer_editing(self, editing_type):
        if editing_type == 'Add to existing':
            self.ui_helpers.click_element("xpath", self.locator_add_to_existing_btn)
        else :
            self.ui_helpers.click_element("xpath", self.locator_replace_all_with_btn)
        time.sleep(1)

    def search_and_select_customer(self, customer_name):
        if customer_name is not None:
            self.ui_helpers.enter_text_action("xpath", self.locator_search_customer_input_box, customer_name)
            self.ui_helpers.press_action_key("xpath", self.locator_search_customer_input_box)
            self.ui_helpers.click_element("xpath", f'({self.locator_select_customer})[1]')
            self.ui_helpers.click_element("xpath", f'({self.locator_select_customer})[3]')
        time.sleep(1)

    def get_information_message(self):
        message = self.ui_helpers.get_text_from_element("xpath", self.locator_get_info_msg)
        time.sleep(1)
        return message

    def select_access_tag(self, access_tag):
        if access_tag is not None:
            self.ui_helpers.enter_text_action("xpath", self.locator_enter_access_tag, access_tag)
            self.ui_helpers.click_element("xpath", f"{self.locator_select_access_tag}//div[@title='{access_tag}']")
        time.sleep(1)

    def select_access_tag_value(self, value):
        if value is not None:
            self.ui_helpers.enter_text_action("xpath", self.locator_enter_access_tag_value, value)
            self.ui_helpers.click_element("xpath", f"{self.locator_select_access_tag_value}//div[@title='{value}']")
        time.sleep(1)
        
    def select_type_of_application_editing(self, editing_type):
        if editing_type == 'Add to existing':
            self.ui_helpers.click_element("xpath", self.locator_add_to_existing_btn_2)
        elif editing_type == 'Replace all with' :
            self.ui_helpers.click_element("xpath", self.locator_replace_all_with_btn_2)
        else :
            self.ui_helpers.click_element("xpath", self.locator_clear_application_permission_btn)
        time.sleep(1)


    def click_save(self):
        self.ui_helpers.click_element("xpath", self.locator_save_button)
        time.sleep(1)

    def accept_confirmation_prompt(self, value):
        if value.lower() == 'yes':
            self.ui_helpers.click_element("xpath", self.locator_yes_button)
        elif value.lower() == 'no':
            self.ui_helpers.click_element("xpath", self.locator_no_button)
        time.sleep(1)

    def get_confirmation_prompt_message(self):
        message = self.ui_helpers.get_text_from_element("xpath", self.locator_confirmation_prompt_msg)
        time.sleep(1)
        return message

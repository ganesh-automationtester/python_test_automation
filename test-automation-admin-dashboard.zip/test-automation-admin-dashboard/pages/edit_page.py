import time

from selenium.webdriver import Keys
from selenium.webdriver.common.by import By

from pages.create_user_page import CreateUserPage
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers


class EditUserPage:
    locator_search_table = "//*[@class='ant-table-container']/div/table/tbody"
    locator_head_view = "//*[@class='user-management-main-home-header color-black']"
    locator_first_name = "register-user_first-name"
    locator_middle_name = "register-user_middle-name"
    locator_last_name = "register-user_last-name"
    locator_email = "register-user_email"
    locator_phone_number = "register-user_phone"
    locator_language = "register-user_language"
    locator_enter_access_tag_value = "(//input[@type='search'])[3]"
    locator_select_access_tag_value = "(//*[@class='rc-virtual-list-holder-inner'])[1]"
    locator_class_customer = '//*[@class="ant-checkbox-wrapper ant-checkbox-wrapper-checked css-i46qwz"]'

    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)
        self.create_page = CreateUserPage(self.driver)

    def table_search(self, data):
        self.ui_helpers.wait_for_element_to_be_present("xpath", self.locator_search_table)
        table_data = self.driver.find_element("xpath", self.locator_search_table)
        table_value = table_data.find_elements(By.TAG_NAME, 'tr')
        for value in table_value:
            if data in value.text:
                row_value = value.find_elements(By.TAG_NAME, 'td')
                for i, row in row_value:
                    if i == 3:
                        row.click()
        time.sleep(1)

    def get_edit_page_header_name(self):
        self.ui_helpers.wait_for_element_to_be_present('xpath', self.locator_head_view, )
        display_message = self.ui_helpers.get_text_from_element("xpath", self.locator_head_view)
        time.sleep(1)
        return display_message

    def edit_first_name(self, first_name):
        enter_first = self.driver.find_element('id', self.locator_first_name)
        enter_first.send_keys(Keys.CONTROL + "a")
        enter_first.send_keys(Keys.DELETE)
        self.ui_helpers.enter_text_action("id", self.locator_first_name, first_name)
        time.sleep(1)

    def edit_middle_name(self, middle_name):
        enter_middle = self.driver.find_element('id', self.locator_middle_name)
        enter_middle.send_keys(Keys.CONTROL + "a")
        enter_middle.send_keys(Keys.DELETE)
        self.ui_helpers.enter_text_action("id", self.locator_middle_name, middle_name)
        time.sleep(1)

    def edit_last_name(self, last_name):
        enter_last = self.driver.find_element('id', self.locator_last_name)
        enter_last.send_keys(Keys.CONTROL + "a")
        enter_last.send_keys(Keys.DELETE)
        self.ui_helpers.enter_text_action("id", self.locator_last_name, last_name)
        time.sleep(1)

    def edit_email(self, email):
        enter_email = self.driver.find_element('id', self.locator_email)
        enter_email.send_keys(Keys.CONTROL + "a")
        enter_email.send_keys(Keys.DELETE)
        self.ui_helpers.enter_text_action("id", self.locator_email, email)
        time.sleep(1)

    def edit_phone_number(self, phone_number):
        enter_phone = self.driver.find_element('id', self.locator_phone_number)
        enter_phone.send_keys(Keys.CONTROL + "a")
        enter_phone.send_keys(Keys.DELETE)
        self.ui_helpers.enter_text_action("id", self.locator_phone_number, phone_number)
        time.sleep(1)

    def edit_customer(self, customer_name=None):
        customer_name_list = []
        try:
            if customer_name is not None:
                customer_list = self.driver.find_elements("xpath", self.locator_class_customer)
                for customer in customer_list:
                    customer_name_list.append(customer.text)
                    if customer_name in customer_name_list:
                        self.ui_helpers.click_element("xpath", f'//*[text()="{customer_name}"]')
                    else:
                        self.create_page.select_customer(customer_name)
        except:
            self.log.info('Error in the edit customer module')
        time.sleep(1)

    def edit_access_tag_value(self, value):
        try:
            if value is not None:
                self.ui_helpers.enter_text_action("xpath", self.locator_enter_access_tag_value, value)
                self.ui_helpers.click_element("xpath", f"{self.locator_select_access_tag_value}//div[@title='{value}']")
        except:
            self.log.info("Element not present on the edit page.")
        time.sleep(1)

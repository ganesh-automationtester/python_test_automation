import time

from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.common.by import By
from utils.custom_logger import CustomLogger
from utils.ui_helpers import UIHelpers
import constants


class CreateUserPage:
    # Write locators here
    locator_single_user = "//*[text()='Single User']"
    locator_add_user_heading = "//*[text()='Add New User']"
    locator_first_name = "register-user_first-name"
    locator_middle_name = "register-user_middle-name"
    locator_last_name = "register-user_last-name"
    locator_email = "register-user_email"
    locator_phone_number = "register-user_phone"
    locator_enter_country_code = "(//input[@type='search'])[1]"
    locator_select_country_code = "(//*[@class='rc-virtual-list-holder-inner'])[1]"
    locator_save = "//span[text()='Save']"
    locator_cancel = "//span[text()='Cancel']"
    locator_back = "//span[@class='anticon user-management-user-form-left-btn']"
    locator_customer_db = '//*[@title="Customer Dashboard"]'
    locator_schedule_db = '//*[@title="Schedules Dashboard"]'
    locator_device_db = '//*[@title="Device Management"]'
    locator_admin_db = '//*[@title="Admin Dashboard"]'
    locator_alarm_db = '//*[@title="Alarms Management"]'
    locator_user_db = '//*[@title="User Management"]'
    locator_class_customer = "ant-checkbox-input"
    locator_enter_access_tag = "(//input[@type='search'])[2]"
    locator_enter_access_tag_value = "(//input[@type='search'])[3]"
    locator_select_access_tag = "(//*[@class='rc-virtual-list-holder-inner'])[1]"
    locator_select_access_tag_value = "(//*[@class='rc-virtual-list-holder-inner'])[2]"
    locator_toast_message = "//*[@class='Toastify']"
    locator_first_name_error = "register-user_first-name_help"
    locator_last_name_error = "register-user_last-name_help"
    locator_email_error = "register-user_email_help"
    locator_phone_number_error = "register-user_phone_help"
    locator_click_dropdown = "//div[@class='custom-tree-permission-container']//div[@class='d-flex']"
    locator_customer_error = "//div[@class='customer-and-sites-error-msg']"

    log = CustomLogger.log()

    def __init__(self, driver):
        self.driver = driver
        self.ui_helpers = UIHelpers(self.driver)

    def single_user_click(self):
        self.ui_helpers.wait_for_element_to_be_clickable('xpath', self.locator_single_user)
        self.ui_helpers.click_element("xpath", self.locator_single_user)
        time.sleep(1)

    def get_create_user_page_heading(self):
        self.ui_helpers.wait_for_element_to_be_displayed(self.locator_add_user_heading, "xpath")
        display_message = self.ui_helpers.get_text_from_element("xpath", self.locator_add_user_heading)
        time.sleep(1)
        return display_message

    def enter_first_name(self, first_name):
        self.ui_helpers.enter_text_action("id", self.locator_first_name, first_name)
        time.sleep(1)

    def enter_middle_name(self, middle_name=""):
        self.ui_helpers.enter_text_action("id", self.locator_middle_name, middle_name)
        time.sleep(1)

    def enter_last_name(self, last_name):
        self.ui_helpers.enter_text_action("id", self.locator_last_name, last_name)
        time.sleep(1)

    def enter_email(self, email):
        self.ui_helpers.enter_text_action("id", self.locator_email, email)
        time.sleep(1)

    def enter_phone_number(self, phone_number):
        self.ui_helpers.enter_text_action("id", self.locator_phone_number, phone_number)
        time.sleep(1)

    def select_country_code(self, country_code):
        try:
            self.ui_helpers.click_element("xpath", self.locator_enter_country_code)
            country_code_list = self.driver.find_element("xpath", self.locator_select_country_code)
            code_list = country_code_list.find_elements("xpath", './child::*')
            for code_name in code_list:
                if code_name.text == country_code:
                    code_name.click()
        except:
            self.log.info("Element not present on the page.")
        time.sleep(1)

    def click_save_button(self):
        self.ui_helpers.scroll_into_element("xpath", self.locator_save)
        self.ui_helpers.click_element("xpath", self.locator_save)
        time.sleep(1)

    def click_cancel_button(self):
        self.ui_helpers.scroll_into_element("xpath", self.locator_cancel)
        self.ui_helpers.click_element("xpath", self.locator_cancel)
        time.sleep(1)

    def click_back_button(self):
        self.ui_helpers.click_element("xpath", self.locator_back)
        time.sleep(1)

    def select_customer(self, customer_name):
        try:
            if customer_name is not None:
                customer_list = self.driver.find_elements("xpath", "//*[@class='ant-checkbox-wrapper css-i46qwz']")
                for customer in customer_list:
                    if customer.text == customer_name:
                        input_customer_name = customer.find_element(By.TAG_NAME, 'input')
                        input_customer_name.click()
                        self.ui_helpers.click_element("xpath", f'//*[text()="{customer_name}"]')
        except:
            self.log.info("Customer name not present on the page.")
        time.sleep(1)

    def select_access_tag(self, access_tag):
        try:
            if access_tag is not None:
                self.ui_helpers.enter_text_action("xpath", self.locator_enter_access_tag, access_tag)
                self.ui_helpers.click_element("xpath", f"{self.locator_select_access_tag}//div[@title='{access_tag}']")
        except:
            self.log.info("Element not present on the page.")
        time.sleep(1)

    def select_access_tag_value(self, value):
        try:
            if value is not None:
                self.ui_helpers.enter_text_action("xpath", self.locator_enter_access_tag_value, value)
                self.ui_helpers.click_element("xpath", f"{self.locator_select_access_tag_value}//div[@title='{value}']")
        except:
            self.log.info("Element not present on the page.")
        time.sleep(1)

    def select_application_and_permission_group(self, application_name, permission_group=constants.BASIC):
        self.ui_helpers.scroll_into_element("xpath", self.locator_cancel)
        achains = ActionChains(self.driver)
        if len(self.driver.find_elements(By.XPATH, self.locator_click_dropdown)) == 8:
            dict_1 = {constants.ALARM_MANAGEMENT: 1, constants.USER_MANAGEMENT: 2, constants.CUSTOMER_DASHBOARD: 3,
                      constants.DEVICE_MANAGEMENT: 4, constants.SCHEDULE_DASHBOARD: 5, constants.CLIENT_APP :6, constants.MAKER_SUITE :7, constants.PARTNER_PORTAL :8}
        else:
            dict_1 = {constants.CUSTOMER_DASHBOARD: 1, constants.DEVICE_MANAGEMENT: 2, constants.SCHEDULE_DASHBOARD: 3, constants.CLIENT_APP :4, constants.MAKER_SUITE :5, constants.PARTNER_PORTAL :6}
        self.ui_helpers.click_element("xpath", f"//*[@title='{application_name.title()}']")
        if permission_group != constants.BASIC:
            self.ui_helpers.click_element("xpath",
                                          f"({self.locator_click_dropdown})[{dict_1[application_name.title()]}]")
            if application_name == constants.USER_MANAGEMENT:
                if permission_group == constants.INTERMEDIATE:
                    self.ui_helpers.action_class_select(1)
            elif application_name == constants.SCHEDULE_DASHBOARD:
                if permission_group == constants.INTERMEDIATE:
                    self.ui_helpers.action_class_select(1)
                elif permission_group == constants.INTERMEDIATE2:
                    self.ui_helpers.action_class_select(2)
                elif permission_group == constants.ADVANCED:
                    self.ui_helpers.action_class_select(3)
            else:
                if permission_group == constants.INTERMEDIATE:
                    self.ui_helpers.action_class_select(1)
                elif permission_group == constants.ADVANCED:
                    self.ui_helpers.action_class_select(2)
        time.sleep(1)

    def select_language(self, language_name):
        if language_name == 'English' or language_name == 'english':
            self.ui_helpers.click_element("xpath", "//*[@value='english']")
        else:
            self.ui_helpers.click_element("xpath", "//*[@value='french']")
        time.sleep(1)

    def select_notification(self, notification_name):
        if notification_name == 'Email' or notification_name == 'email':
            self.ui_helpers.click_element("xpath", "//*[@value='email']")
        elif notification_name == 'SMS' or notification_name == 'sms':
            self.ui_helpers.click_element("xpath", "//*[@value='sms']")
        elif notification_name == 'both' or notification_name == 'Both':
            self.ui_helpers.click_element("xpath", "//*[@value='both']")
        else:
            self.log.info("Phone number not provided for selecting option")
        time.sleep(1)

    def select_unit(self, unit_name):
        if unit_name == 'Metric' or unit_name == 'metric':
            self.ui_helpers.click_element("xpath", "//*[@value='metric']")
        else:
            self.ui_helpers.click_element("xpath", "//*[@value='imperial']")
        time.sleep(1)

    def getFirstNameErrorMessage(self):
        display_message = self.ui_helpers.get_text_from_element("id", self.locator_first_name_error)
        time.sleep(1)
        return display_message

    def getLastNameErrorMessage(self):
        display_message = self.ui_helpers.get_text_from_element("id", self.locator_last_name_error)
        time.sleep(1)
        return display_message

    def getEmailErrorMessage(self):
        display_message = self.ui_helpers.get_text_from_element("id", self.locator_email_error)
        time.sleep(1)
        return display_message

    def getPhoneNumberErrorMessage(self):
        display_message = self.ui_helpers.get_text_from_element("id", self.locator_phone_number_error)
        time.sleep(1)
        return display_message

    def getCustomerErrorMessage(self):
        display_message = self.ui_helpers.get_text_from_element('xpath', self.locator_customer_error)
        time.sleep(1)
        return display_message
    
    
    def setnewpassword(self,url, username, password):
        self.driver.geturl(url)
        self.ui_helpers.enter_text_action("id", self.locator_username, username)
        self.ui_helpers.enter_text_action("id", self.locator_password, password)
        self.ui_helpers.enter_text_action("id", self.locator_re_enter_password, password)
        self.ui_helpers.click_element("id", self.locator_privacy_policy_read)
        self.ui_helpers.click_element("xpath", self.locator_agree_btn)
        self.ui_helpers.click_element("id", self.locator_next_btn)
        

